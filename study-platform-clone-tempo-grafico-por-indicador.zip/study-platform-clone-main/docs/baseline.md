# Baseline e registro de verificação

Preenchido pela execução do plano de implementação (Fase 0). Datas em 2026.

## Ambiente da execução automatizada

- Node 22.22 e `tsc` disponíveis; **sem rede, sem `node_modules`, sem Postgres/Supabase**.
- Portanto **não foram executados**: `npm install`, `npm run lint`, `npm test` (Vitest real),
  `npm run build` e qualquer SQL.
- Testes novos foram executados com um shim de `node:test` no lugar do Vitest
  (mesma sintaxe `describe/it/expect`); o resultado precisa ser reconfirmado com `npm test`.

## O que o humano deve rodar para completar a Fase 0

1. `npm install`
2. `npm run lint && npm test && npm run build` — registre aqui o resultado ANTES de aplicar
   qualquer migração, para separar falhas pré-existentes das novas.
3. Criar projeto Supabase de teste e aplicar `drizzle/migrations/0000` a `0004`.

## Observações sobre o estado inicial do repositório

- O ESLint inclui `eslint-plugin-prettier`, e o Prettier (`printWidth: 100`) acusa erro em linhas
  longas. Há dezenas de linhas acima de 100 colunas em `indicators.ts`, `dca-bot-sample.tsx`,
  `bots.$botId.tsx`, `edit-bot-dialog.tsx`, `indicator-fields.tsx`, `bots.new.tsx`,
  `bots.functions.ts` e `guide.tsx`. É provável que `npm run lint` já falhe antes das mudanças;
  a Fase 8 (`npm run format`) resolve isso.
- Checagem de tipos parcial (sem dependências) do commit inicial: 125 mensagens, todas por módulos
  ausentes ou por tipos de React indisponíveis nesse modo.

## Histórico

Ver a seção 14 do plano de implementação.
