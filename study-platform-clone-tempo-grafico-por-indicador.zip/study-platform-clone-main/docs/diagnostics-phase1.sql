-- Diagnóstico da Fase 1: rode ANTES de aplicar 0005_integrity_constraints.sql.
-- Cada consulta deve retornar ZERO linhas. Se retornar, decida com o responsável (mesclar/fechar/corrigir).

-- 1. Operações abertas duplicadas por (bot, par)
SELECT bot_id, pair, count(*) AS abertas FROM public.deals WHERE status = 'open' GROUP BY 1, 2 HAVING count(*) > 1;

-- 2. Saldos negativos
SELECT user_id, currency, balance FROM public.paper_balances WHERE balance < 0;

-- 3. Operações com status inválido ou valores não positivos
SELECT id, status, invested, quantity, entry_price FROM public.deals
WHERE status NOT IN ('open','completed') OR invested <= 0 OR quantity <= 0 OR entry_price <= 0;

-- 4. Bots fora dos limites de src/lib/bot-limits.ts
SELECT id, name, status, pair, pairs, timeframe FROM public.bots
WHERE status NOT IN ('active','paused','stopped')
   OR NOT (base_order_size > 0 AND safety_order_size > 0
           AND max_safety_orders BETWEEN 0 AND 10
           AND price_deviation_pct BETWEEN 0.1 AND 20
           AND take_profit_pct BETWEEN 0.1 AND 50
           AND (stop_loss_pct IS NULL OR stop_loss_pct BETWEEN 0.5 AND 80)
           AND timeframe IN ('3m','5m','15m','30m','1h','4h','1d','1w')
           AND cardinality(pairs) BETWEEN 1 AND 100)
   OR pair !~ '^[A-Z0-9]{2,15}/USDT$';
