# Roadmap — Clone de estudo estilo 3Commas ("TradeBots")

- [x] Ativar login por e-mail + Google (Lovable Cloud)
- [x] Criar schema: profiles, bots (DCA), deals, paper_balances
- [x] Design system dark fintech (tema escuro, acento verde/teal)
- [x] Página /auth (login + cadastro + Google)
- [x] Layout autenticado com sidebar
- [x] /dashboard — visão geral do portfólio e stats
- [x] /markets — preços ao vivo (CoinGecko)
- [x] /bots — lista de bots + criar bot DCA
- [x] /bots/$id — detalhe do bot, deals, gráfico
- [x] Motor de simulação paper trading (server functions)
- [x] Metadados head() em todas as rotas
- [x] Verificar build + fluxo ponta a ponta
- [x] Amostra interativa do formulário DCA baseada nas capturas, sem alterar o simulador
- [x] Editar configurações de bots existentes, preservando histórico e validar salvamento

- [x] Configurar e trocar indicadores na criação e edição, com salvamento e validação

- [x] Adicionar ADX, MFI, médias móveis, SAR Parabolic, BB% e Stochastic com configurações e validação

- [x] Ultimate Oscillator, CCI e Heikin Ashi
- [x] Intervalos 3m, 5m, 15m, 30m, 1h, 4h, 1d e 1w
- [x] Múltiplos pares e até três indicadores por bot, criação/edição compatíveis
- [x] Mercado inspirado no mercado spot USDT da Binance
- [x] Guia detalhado de uso e explicação da conta de simulação
- [x] Renomear conta, adicionar fundos e resetar saldo/histórico de simulação
- [x] Verificar criação/edição autenticada, mercado/livro real, renomear conta, confirmação de reset e 14 testes
- [ ] Validar reset e adição executados ponta a ponta — bloqueado para evitar alterar saldo/histórico real do usuário; ambiente não permite teste transacional com papel autenticado
- [ ] Grid e SmartTrade — módulos ainda não implementados nesta entrega DCA
- [ ] Catálogo completo Binance Spot USDT, busca e validação — aguardando aprovação do diagnóstico e plano solicitados no documento.
- [ ] Seguir as imagens na seleção: botão Adicionar par, lista suspensa com busca e caixas de seleção; preservar o restante da tela e o escopo Spot.
