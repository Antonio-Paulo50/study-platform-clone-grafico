# Code graph report

- Generated: 2026-10-15T17:19:18.809776+00:00
- Files mapped: 119
- Dependency links: 425
