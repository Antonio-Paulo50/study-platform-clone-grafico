<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep authenticated product pages under the `_authenticated` pathless layout; it centralizes the client-side session gate and shared navigation.
- Keep live market access and paper-trading mutations in TanStack server functions; this protects user-scoped operations and isolates external API calls.
- Keep DCA configuration previews separate from the executable bot form; unsupported preview settings must never silently become trading instructions.
- Share validated entry settings between bot creation and editing; evaluate completed OHLCV candles at each indicator's own saved timeframe (legacy indicators without one fall back to `bots.timeframe`, which mirrors the first indicator) with technicalindicators, combining conditions with AND, so both forms and execution agree. Preserve legacy Bollinger settings but offer BB% for new selections.
- Keep per-pair deals separate while sharing the user paper wallet; account management uses authenticated transactional database functions so resets and fund additions remain owner-scoped.
- Keep the user guide explicit about simulation limitations; displayed exchange data is not a claim of real order execution or continuous automation.
