import { describe, expect, it } from "vitest";
import { paperActionSchema } from "@/lib/paper-account.functions";
describe("paper account validation", () => {
  it("requires an explicit reset confirmation", () => {
    expect(paperActionSchema.safeParse({ action: "reset", confirmation: "RESETAR" }).success).toBe(true);
    expect(paperActionSchema.safeParse({ action: "reset" }).success).toBe(false);
  });
  it("limits funds and validates names", () => {
    for (const amount of [-1, 0, NaN, Infinity, 1000001]) expect(paperActionSchema.safeParse({ action: "add", amount }).success).toBe(false);
    expect(paperActionSchema.safeParse({ action: "add", amount: 1000 }).success).toBe(true);
    expect(paperActionSchema.safeParse({ action: "rename", name: "  " }).success).toBe(false);
    expect(paperActionSchema.parse({ action: "rename", name: " Estudo " })).toEqual({ action: "rename", name: "Estudo" });
  });
});