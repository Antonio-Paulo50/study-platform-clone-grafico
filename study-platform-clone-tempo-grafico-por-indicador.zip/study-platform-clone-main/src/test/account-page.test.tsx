import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { fireEvent, render, screen, waitFor, cleanup } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const getFn = vi.fn();
const manageFn = vi.fn();

vi.mock("@tanstack/react-start", async (orig) => ({
  ...(await orig<typeof import("@tanstack/react-start")>()),
  useServerFn: (fn: unknown) => fn,
}));
vi.mock("@tanstack/react-router", async (orig) => ({
  ...(await orig<typeof import("@tanstack/react-router")>()),
  Link: ({ children, to }: { children: React.ReactNode; to: string }) => (
    <a href={to}>{children}</a>
  ),
}));
vi.mock("@/lib/paper-account.functions", async (orig) => ({
  ...(await orig<typeof import("@/lib/paper-account.functions")>()),
  getPaperAccount: (...a: unknown[]) => getFn(...a),
  managePaperAccount: (...a: unknown[]) => manageFn(...a),
}));

import { Route } from "@/routes/_authenticated/account";

function renderPage() {
  const Page = Route.options.component as () => React.JSX.Element;
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={qc}>
      <Page />
    </QueryClientProvider>,
  );
}

beforeEach(() => {
  getFn.mockResolvedValue({
    name: "Minha conta",
    balance: 7500.5,
    invested: 1200,
    historyCount: 4,
  });
  manageFn.mockResolvedValue({ balance: 1 });
});
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

describe("Conta (conta única)", () => {
  it("mostra nome, saldo, investido e histórico vindos do servidor", async () => {
    renderPage();
    expect((await screen.findAllByText(/\$7,500\.50/)).length).toBeGreaterThan(0);
    expect(screen.getAllByText("Minha conta").length).toBeGreaterThan(0);
    expect(screen.getByText(/4 negociação\(ões\)/)).toBeInTheDocument();
  });

  it("adiciona fundos com a ação 'add'", async () => {
    renderPage();
    await screen.findAllByText(/\$7,500\.50/);
    fireEvent.click(screen.getByRole("button", { name: /adicionar fundos/i }));
    const input = await screen.findByLabelText(/valor em usdt/i);
    fireEvent.change(input, { target: { value: "2500" } });
    fireEvent.click(screen.getByRole("button", { name: /^adicionar$/i }));
    await waitFor(() =>
      expect(manageFn).toHaveBeenCalledWith({ data: { action: "add", amount: 2500 } }),
    );
  });

  it("renomeia com a ação 'rename'", async () => {
    renderPage();
    await screen.findAllByText(/\$7,500\.50/);
    fireEvent.click(screen.getByRole("button", { name: /^renomear$/i }));
    const input = await screen.findByLabelText(/novo nome/i);
    fireEvent.change(input, { target: { value: "Estudo BTC" } });
    fireEvent.click(screen.getByRole("button", { name: /^salvar$/i }));
    await waitFor(() =>
      expect(manageFn).toHaveBeenCalledWith({ data: { action: "rename", name: "Estudo BTC" } }),
    );
  });

  it("só restaura depois de digitar RESETAR", async () => {
    renderPage();
    await screen.findAllByText(/\$7,500\.50/);
    fireEvent.click(screen.getByRole("button", { name: /restaurar para \$10\.000/i }));
    const confirmBtn = await screen.findByRole("button", { name: /^restaurar conta$/i });
    expect(confirmBtn).toBeDisabled();
    fireEvent.change(screen.getByLabelText(/digite/i), { target: { value: "resetar" } });
    expect(confirmBtn).toBeDisabled();
    fireEvent.change(screen.getByLabelText(/digite/i), { target: { value: "RESETAR" } });
    expect(confirmBtn).toBeEnabled();
    fireEvent.click(confirmBtn);
    await waitFor(() =>
      expect(manageFn).toHaveBeenCalledWith({ data: { action: "reset", confirmation: "RESETAR" } }),
    );
  });

  it("mostra aviso com opção de tentar de novo quando o servidor falha", async () => {
    getFn.mockRejectedValueOnce(new Error("falhou"));
    renderPage();
    expect(await screen.findByText(/não foi possível carregar a conta/i)).toBeInTheDocument();
  });
});
