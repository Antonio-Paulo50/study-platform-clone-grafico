import { describe, expect, it } from "vitest";
import {
  buildLadder,
  buildOpenAction,
  cumulativeDropPct,
  decideEntry,
  entryPrecheck,
  evaluateDeal,
  floorToStep,
  maxDealCost,
  round8,
  safetyOrderSize,
  safetyTriggerPrice,
  type BotConfig,
  type DealState,
} from "@/lib/engine";

const bot: BotConfig = {
  id: "bot-1",
  status: "active",
  baseOrderSize: 100,
  safetyOrderSize: 100,
  maxSafetyOrders: 3,
  priceDeviationPct: 2,
  takeProfitPct: 2,
  stopLossPct: null,
};

const deal: DealState = {
  id: "deal-1",
  pair: "BTC/USDT",
  basePrice: 100,
  avgPrice: 100,
  invested: 100,
  quantity: 1,
  safetyOrdersUsed: 0,
};

const quote = (bid: number, ask = bid) => ({ bid, ask });

describe("math", () => {
  it("round8 limita a 8 casas", () => {
    expect(round8(1 / 3)).toBe(0.33333333);
    expect(round8(0.1 + 0.2)).toBe(0.3);
  });
  it("floorToStep arredonda para baixo sem erro de ponto flutuante", () => {
    expect(floorToStep(0.123456, 0.001)).toBe(0.123);
    expect(floorToStep(0.3, 0.1)).toBe(0.3);
    expect(floorToStep(5, 0)).toBe(5);
  });
});

describe("escada de ordens de segurança", () => {
  it("queda acumulada: exemplo oficial da 3Commas (desvio 0,5 e step 2)", () => {
    expect([1, 2, 3].map((n) => cumulativeDropPct(n, 0.5, 2))).toEqual([0.5, 1.5, 3.5]);
  });
  it("com step 1 a queda é n × desvio", () => {
    expect([1, 2, 3].map((n) => cumulativeDropPct(n, 2, 1))).toEqual([2, 4, 6]);
  });
  it("gatilhos medidos a partir da ordem base: 98, 96, 94", () => {
    const prices = [1, 2, 3].map((n) => safetyTriggerPrice(100, n, 2));
    prices.forEach((price, i) => expect(price).toBeCloseTo([98, 96, 94][i], 8));
  });
  it("tamanho por nível com volume scale 2: 10, 20, 40", () => {
    expect([1, 2, 3].map((n) => safetyOrderSize(10, n, 2))).toEqual([10, 20, 40]);
    expect(safetyOrderSize(10, 3)).toBe(10);
  });
  it("rejeita nível inválido", () => {
    expect(() => cumulativeDropPct(0, 2)).toThrow();
    expect(() => safetyOrderSize(10, 1.5)).toThrow();
  });
  it("o preço de gatilho nunca fica negativo", () => {
    expect(safetyTriggerPrice(100, 2, 20, 10)).toBe(0);
  });
  it("buildLadder e maxDealCost entregam a tabela completa", () => {
    const scaled = {
      ...bot,
      baseOrderSize: 10,
      safetyOrderSize: 10,
      priceDeviationPct: 0.5,
      safetyStepScale: 2,
      safetyVolumeScale: 2,
    };
    const rows = buildLadder(scaled, 100);
    expect(rows.map((r) => r.dropPct)).toEqual([0.5, 1.5, 3.5]);
    expect(rows.map((r) => r.size)).toEqual([10, 20, 40]);
    expect(rows.map((r) => r.cumulativeCost)).toEqual([20, 40, 80]);
    expect(rows[0].triggerPrice).toBeCloseTo(99.5, 8);
    expect(rows[2].triggerPrice).toBeCloseTo(96.5, 8);
    expect(maxDealCost(scaled)).toBe(80);
  });
});

describe("evaluateDeal", () => {
  it("bot pausado ou parado não gera ação", () => {
    expect(evaluateDeal({ ...bot, status: "paused" }, deal, quote(110))).toEqual([]);
    expect(evaluateDeal({ ...bot, status: "stopped" }, deal, quote(110))).toEqual([]);
  });
  it("cotação inválida não gera ação", () => {
    expect(evaluateDeal(bot, deal, { bid: 0, ask: 100 })).toEqual([]);
  });
  it("take profit: fecha ao atingir o alvo sobre o preço médio", () => {
    expect(evaluateDeal(bot, deal, quote(101.99))).toEqual([]);
    const [action] = evaluateDeal(bot, deal, quote(102));
    expect(action).toEqual({
      type: "close",
      dealId: "deal-1",
      reason: "take_profit",
      price: 102,
      quantity: 1,
      quoteAmount: 102,
    });
  });
  it("stop loss: fecha quando o bid cai ao preço de stop", () => {
    const withStop = { ...bot, stopLossPct: 5 };
    expect(evaluateDeal(withStop, deal, quote(95.01))[0]?.type).not.toBe("close");
    const [action] = evaluateDeal(withStop, deal, quote(95));
    expect(action).toMatchObject({ type: "close", reason: "stop_loss", price: 95 });
  });
  it("stop loss tem prioridade sobre ordem de segurança", () => {
    const withStop = { ...bot, stopLossPct: 3 };
    const [action] = evaluateDeal(withStop, deal, { bid: 96.9, ask: 97 });
    expect(action.type).toBe("close");
  });
  it("ordem de segurança nível 1 dispara em 98 e só então", () => {
    expect(evaluateDeal(bot, deal, quote(98.01))).toEqual([]);
    const [action] = evaluateDeal(bot, deal, quote(98));
    expect(action).toEqual({
      type: "safety",
      dealId: "deal-1",
      level: 1,
      price: 98,
      quantity: round8(100 / 98),
      quoteAmount: 100,
    });
  });
  it("nível 2 usa a ORDEM BASE, não o preço médio (96 e não 95,03)", () => {
    const afterOne: DealState = {
      ...deal,
      safetyOrdersUsed: 1,
      invested: 200,
      quantity: 1 + 100 / 98,
      avgPrice: 200 / (1 + 100 / 98),
    };
    expect(afterOne.avgPrice).toBeCloseTo(98.9899, 3);
    expect(evaluateDeal(bot, afterOne, quote(96.5))).toEqual([]);
    const [action] = evaluateDeal(bot, afterOne, quote(96));
    expect(action).toMatchObject({ type: "safety", level: 2, price: 96 });
    // regra antiga (relativa ao preço médio) dispararia em ~95,03: documentado aqui
    const legacyTrigger = afterOne.avgPrice * (1 - (2 * 2) / 100);
    expect(legacyTrigger).toBeCloseTo(95.03, 2);
  });
  it("aplica o volume scale ao tamanho da ordem de segurança", () => {
    const scaled = { ...bot, safetyOrderSize: 10, safetyVolumeScale: 2 };
    const second: DealState = { ...deal, safetyOrdersUsed: 1 };
    const [action] = evaluateDeal(scaled, second, quote(96));
    expect(action).toMatchObject({ type: "safety", level: 2, quoteAmount: 20 });
  });
  it("respeita o máximo de ordens de segurança", () => {
    const maxed: DealState = { ...deal, safetyOrdersUsed: 3 };
    expect(evaluateDeal(bot, maxed, quote(50))).toEqual([]);
  });
  it("não compra segurança sem saldo suficiente", () => {
    expect(evaluateDeal(bot, deal, quote(98), 99.99)).toEqual([]);
    expect(evaluateDeal(bot, deal, quote(98), 100)).toHaveLength(1);
  });
});

describe("entrada", () => {
  it("bot inativo, cotação inválida e saldo insuficiente impedem a abertura", () => {
    expect(entryPrecheck({ ...bot, status: "paused" }, quote(100), 1000)).toBe("bot_inactive");
    expect(entryPrecheck(bot, { bid: 0, ask: 0 }, 1000)).toBe("invalid_quote");
    expect(entryPrecheck(bot, quote(100), 99.99)).toBe("insufficient_balance");
    expect(entryPrecheck(bot, quote(100), 100)).toBeNull();
  });
  it("sem sinal do indicador aguarda; com sinal abre ao ask", () => {
    expect(decideEntry(bot, "BTC/USDT", quote(99, 100), 1000, false)).toEqual({
      skipped: "waiting_signal",
    });
    expect(decideEntry(bot, "BTC/USDT", quote(99, 100), 1000, true)).toEqual({
      action: {
        type: "open",
        botId: "bot-1",
        pair: "BTC/USDT",
        price: 100,
        quantity: 1,
        quoteAmount: 100,
        basePrice: 100,
      },
    });
  });
  it("a quantidade é arredondada a 8 casas", () => {
    expect(buildOpenAction(bot, "ETH/USDT", quote(2999, 3000)).quantity).toBe(0.03333333);
  });
});
