import { describe, expect, it } from "vitest";
import { describeEntry, entryTimeframe, describeIndicator, evaluateIndicator, evaluateCandleIndicator, indicatorConfigSchema, indicatorConfigsSchema, DEFAULT_INDICATORS, TIMEFRAMES, timeframeSchema, type MarketCandle } from "@/lib/indicators";

describe("indicator configuration", () => {
  it("accepts RSI 14 crossing upward through 50", () => {
    const config = indicatorConfigSchema.parse({ type: "rsi", period: 14, level: 50, condition: "cross_up" });
    expect(describeIndicator(config)).toBe("RSI 14 cruzando para cima 50");
  });
  it("rejects invalid MACD periods", () => {
    expect(indicatorConfigSchema.safeParse({ type: "macd", fast: 26, slow: 12, signal: 9, condition: "cross_up" }).success).toBe(false);
  });
  it("waits for enough samples", () => {
    expect(evaluateIndicator({ type: "rsi", period: 14, level: 50, condition: "cross_up" }, [1, 2, 3])).toBe(false);
  });
  it("detects an RSI upward crossing", () => {
    expect(evaluateIndicator({ type: "rsi", period: 2, level: 50, condition: "cross_up" }, [10, 9, 8, 12])).toBe(true);
  });
  it("validates every default including all nine added indicators", () => {
    for (const config of Object.values(DEFAULT_INDICATORS)) expect(indicatorConfigSchema.safeParse(config).success).toBe(true);
  });
  it("allows up to three conditions and only requested timeframes", () => {
    expect(indicatorConfigsSchema.safeParse([DEFAULT_INDICATORS.rsi, DEFAULT_INDICATORS.cci, DEFAULT_INDICATORS.adx]).success).toBe(true);
    expect(indicatorConfigsSchema.safeParse(Array(4).fill(DEFAULT_INDICATORS.rsi)).success).toBe(false);
    expect(indicatorConfigsSchema.safeParse([]).success).toBe(false);
    for (const interval of Object.keys(TIMEFRAMES)) expect(timeframeSchema.safeParse(interval).success).toBe(true);
    expect(timeframeSchema.safeParse("2m").success).toBe(false);
  });
  it("rejects inconsistent periods and accelerations", () => {
    expect(indicatorConfigSchema.safeParse({ ...DEFAULT_INDICATORS.ultimate, fast: 28, middle: 14 }).success).toBe(false);
    expect(indicatorConfigSchema.safeParse({ ...DEFAULT_INDICATORS.sar, step: 0.1, max: 0.05 }).success).toBe(false);
    expect(indicatorConfigSchema.safeParse({ ...DEFAULT_INDICATORS.ma, fast: 30, slow: 10 }).success).toBe(false);
  });
  const candles: MarketCandle[] = Array.from({ length: 120 }, (_, i) => ({ time: i * 300000, open: 100 + i, high: 103 + i, low: 99 + i, close: 102 + i, volume: 100 + i }));
  it("safely evaluates every candle indicator", () => {
    for (const config of Object.values(DEFAULT_INDICATORS)) {
      expect(typeof evaluateCandleIndicator(config, candles, "5m")).toBe("boolean");
      expect(evaluateCandleIndicator(config, [])).toBe(false);
    }
  });
  it("detects bullish Heikin Ashi and not a nonexistent reversal", () => {
    expect(evaluateCandleIndicator({ type: "heikin_ashi", count: 3, condition: "bullish" }, candles)).toBe(true);
    expect(evaluateCandleIndicator({ type: "heikin_ashi", count: 3, condition: "turn_bullish" }, candles)).toBe(false);
  });
  it("uses elapsed hours for price variation even on 5 minute candles", () => {
    expect(evaluateCandleIndicator({ type: "price_change", hours: 1, pct: 5, condition: "rise" }, candles, "5m")).toBe(true);
    expect(evaluateCandleIndicator({ type: "price_change", hours: 24, pct: 1, condition: "rise" }, candles, "5m")).toBe(false);
  });
  it("detects a rising Ultimate Oscillator without division by zero", () => {
    expect(evaluateCandleIndicator({ type: "ultimate", fast: 7, middle: 14, slow: 28, condition: "above", level: 50 }, candles)).toBe(true);
    expect(evaluateCandleIndicator(DEFAULT_INDICATORS.ultimate, candles.map(v => ({ ...v, open: 1, high: 1, low: 1, close: 1 })))).toBe(false);
  });
});

describe("per-indicator timeframe", () => {
  it("keeps each indicator's own timeframe when parsing the list", () => {
    const parsed = indicatorConfigsSchema.parse([
      { ...DEFAULT_INDICATORS.rsi, timeframe: "4h" },
      { ...DEFAULT_INDICATORS.cci, timeframe: "15m" },
      DEFAULT_INDICATORS.adx,
    ]) as { timeframe?: string }[];
    expect(parsed.map(c => c.timeframe)).toEqual(["4h", "15m", undefined]);
  });
  it("rejects an unsupported timeframe on an indicator", () => {
    expect(indicatorConfigsSchema.safeParse([{ ...DEFAULT_INDICATORS.rsi, timeframe: "2m" }]).success).toBe(false);
  });
  it("falls back to the bot timeframe for legacy indicators", () => {
    expect(entryTimeframe({ timeframe: "4h" }, "1h")).toBe("4h");
    expect(entryTimeframe({}, "15m")).toBe("15m");
    expect(entryTimeframe(undefined)).toBe("1h");
    expect(entryTimeframe({ timeframe: "bogus" }, "5m")).toBe("5m");
  });
  it("describes an indicator together with its timeframe", () => {
    expect(describeEntry({ ...DEFAULT_INDICATORS.rsi, timeframe: "1h" })).toBe("RSI 14 cruzando para cima 30 · 1 hora");
    expect(describeEntry(DEFAULT_INDICATORS.rsi, "4h")).toBe("RSI 14 cruzando para cima 30 · 4 horas");
  });
});
