import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { BOT_LIMITS, inputBounds } from "@/lib/bot-limits";

const migration = readFileSync(path.resolve(process.cwd(), "drizzle/migrations/0005_integrity_constraints.sql"), "utf8");

describe("BOT_LIMITS e a migração 0005 (anti-divergência Zod ↔ banco)", () => {
  it("espelha cada intervalo nas CHECKs do banco", () => {
    const { maxSafetyOrders: so, priceDeviationPct: dev, takeProfitPct: tp, stopLossPct: sl, pairsPerBot: pairs } = BOT_LIMITS;
    expect(migration).toContain(`max_safety_orders BETWEEN ${so.min} AND ${so.max}`);
    expect(migration).toContain(`price_deviation_pct BETWEEN ${dev.min} AND ${dev.max}`);
    expect(migration).toContain(`take_profit_pct BETWEEN ${tp.min} AND ${tp.max}`);
    expect(migration).toContain(`stop_loss_pct BETWEEN ${sl.min} AND ${sl.max}`);
    expect(migration).toContain(`cardinality(pairs) BETWEEN ${pairs.min} AND ${pairs.max}`);
  });
  it("o diagnóstico usa os mesmos limites da migração", () => {
    const diagnostics = readFileSync(path.resolve(process.cwd(), "docs/diagnostics-phase1.sql"), "utf8");
    for (const line of ["max_safety_orders BETWEEN 0 AND 10", "price_deviation_pct BETWEEN 0.1 AND 20", "take_profit_pct BETWEEN 0.1 AND 50", "stop_loss_pct BETWEEN 0.5 AND 80", "cardinality(pairs) BETWEEN 1 AND 100"]) {
      expect(diagnostics).toContain(line);
    }
  });
  it("converte limites em atributos de input", () => {
    expect(inputBounds(BOT_LIMITS.priceDeviationPct)).toEqual({ min: "0.1", max: "20" });
    expect(inputBounds(BOT_LIMITS.orderSize)).toEqual({ min: "1", max: "100000" });
  });
  it("mantém o piso de ordem coerente com a regra do banco (> 0)", () => {
    expect(BOT_LIMITS.orderSize.min).toBeGreaterThan(0);
    expect(migration).toContain("base_order_size > 0 AND safety_order_size > 0");
  });
});
