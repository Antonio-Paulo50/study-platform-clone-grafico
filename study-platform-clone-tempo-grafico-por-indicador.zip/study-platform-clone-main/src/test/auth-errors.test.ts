import { describe, expect, it } from "vitest";
import { translateAuthError } from "@/lib/auth-errors";

describe("translateAuthError", () => {
  it("traduz senha vazada (a mensagem do print)", () => {
    const msg = translateAuthError({
      message: "Password is known to be weak and easy to guess, please choose a different one.",
      code: "weak_password",
      reasons: ["pwned"],
    });
    expect(msg).toMatch(/vazamentos/);
  });
  it("traduz senha fraca mesmo sem code", () => {
    expect(
      translateAuthError({ message: "Password is known to be weak and easy to guess" }),
    ).toMatch(/fraca/);
  });
  it("traduz credenciais inválidas", () => {
    expect(
      translateAuthError({ message: "Invalid login credentials", code: "invalid_credentials" }),
    ).toBe("E-mail ou senha incorretos.");
  });
  it("traduz e-mail não confirmado", () => {
    expect(
      translateAuthError({ code: "email_not_confirmed", message: "Email not confirmed" }),
    ).toMatch(/não foi confirmado/);
  });
  it("traduz limite de envio de e-mails", () => {
    expect(
      translateAuthError({
        code: "over_email_send_rate_limit",
        message: "email rate limit exceeded",
      }),
    ).toMatch(/Muitos e-mails/);
  });
  it("traduz erro de rede", () => {
    expect(translateAuthError(new TypeError("Failed to fetch"))).toMatch(/Sem conexão/);
  });
  it("usa fallback em português para erros desconhecidos", () => {
    expect(translateAuthError({ message: "something weird" })).toBe(
      "Algo deu errado. Tente novamente.",
    );
  });
});
