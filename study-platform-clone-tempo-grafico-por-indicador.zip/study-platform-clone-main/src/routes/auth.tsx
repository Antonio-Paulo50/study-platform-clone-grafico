import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Bot, Loader2, Mail } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { translateAuthError } from "@/lib/auth-errors";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const searchSchema = z.object({
  mode: z.enum(["login", "signup", "forgot"]).optional().catch("login"),
});

export const Route = createFileRoute("/auth")({
  validateSearch: (search) => searchSchema.parse(search),
  head: () => ({
    meta: [
      { title: "Entrar — BotPilot" },
      { name: "description", content: "Acesse sua conta BotPilot ou crie uma nova." },
      { property: "og:title", content: "Entrar — BotPilot" },
      { property: "og:description", content: "Acesse sua conta BotPilot ou crie uma nova." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { mode } = Route.useSearch();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const [emailKind, setEmailKind] = useState<"signup" | "forgot">("signup");
  const [resending, setResending] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  const handleResend = async () => {
    if (resending || cooldown > 0) return;
    setResending(true);
    try {
      if (emailKind === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        toast.success("Link de redefinição reenviado. Verifique também a caixa de spam.");
      } else {
        const { error } = await supabase.auth.resend({
          type: "signup",
          email,
          options: { emailRedirectTo: `${window.location.origin}/auth/callback` },
        });
        if (error) throw error;
        toast.success("E-mail de confirmação reenviado. Verifique também a caixa de spam.");
      }
      setCooldown(60);
    } catch (err) {
      toast.error(translateAuthError(err, "Não foi possível reenviar o e-mail. Tente novamente."));
      // limite de envio: evita novas tentativas imediatas
      if ((err as { status?: number } | null)?.status === 429) setCooldown(60);
    } finally {
      setResending(false);
    }
  };

  const setMode = (m: "login" | "signup" | "forgot") => {
    setEmailSent(false);
    setCooldown(0);
    navigate({ to: "/auth", search: { mode: m }, replace: true });
  };

  const handleGoogle = async () => {
    setGoogleLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: `${window.location.origin}/auth/callback`,
    });
    if (result.error) {
      toast.error("Não foi possível entrar com Google. Tente novamente.");
      setGoogleLoading(false);
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/dashboard" });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setEmailKind("forgot");
        setCooldown(60);
        setEmailSent(true);
        return;
      }
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/auth/callback`,
            data: { full_name: displayName },
          },
        });
        if (error) throw error;
        // E-mail já cadastrado: o Supabase não revela isso por erro, devolve usuário sem identidades.
        if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
          toast.error("Este e-mail já está cadastrado. Entre com sua senha ou use \"Esqueci a senha\".");
          return;
        }
        if (!data.session) {
          setEmailKind("signup");
          setCooldown(60);
          setEmailSent(true);
          return;
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
          if (error.code === "email_not_confirmed") {
            toast.error(translateAuthError(error));
            setEmailKind("signup");
            setEmailSent(true);
            return;
          }
          throw error;
        }
      }
      navigate({ to: "/dashboard" });
    } catch (err) {
      toast.error(translateAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background bg-grid px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <Link to="/" className="inline-flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <Bot className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold tracking-tight">BotPilot</span>
          </Link>
        </div>

        <div className="rounded-xl border border-border bg-card p-6 card-glow">
          {emailSent ? (
            <div className="text-center">
              <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/15">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <h1 className="text-lg font-semibold">Verifique seu e-mail</h1>
              <p className="mt-2 text-sm text-muted-foreground">
                Enviamos um link para <span className="text-foreground">{email}</span>.{" "}
                {emailKind === "signup"
                  ? "Clique nele para confirmar sua conta."
                  : "Clique nele para redefinir sua senha."}
              </p>
              <p className="mt-2 text-xs text-muted-foreground">
                Não chegou? Veja a caixa de spam ou promoções, ou reenvie abaixo.
              </p>
              <Button
                type="button"
                className="mt-5 w-full"
                onClick={handleResend}
                disabled={resending || cooldown > 0}
              >
                {resending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {cooldown > 0
                  ? `Reenviar em ${cooldown}s`
                  : emailKind === "signup"
                    ? "Reenviar e-mail de confirmação"
                    : "Reenviar link de redefinição"}
              </Button>
              <Button variant="outline" className="mt-3 w-full" onClick={() => setMode("login")}>
                Voltar ao login
              </Button>
            </div>
          ) : (
            <>
              <h1 className="text-lg font-semibold">
                {mode === "signup"
                  ? "Crie sua conta"
                  : mode === "forgot"
                    ? "Recuperar senha"
                    : "Bem-vindo de volta"}
              </h1>
              <p className="mt-1 text-sm text-muted-foreground">
                {mode === "signup"
                  ? "Ganhe US$ 10.000 fictícios para simular."
                  : mode === "forgot"
                    ? "Enviaremos um link de redefinição."
                    : "Entre para acessar seus bots."}
              </p>

              <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                {mode === "signup" && (
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome</Label>
                    <Input
                      id="name"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Seu nome"
                      required
                    />
                  </div>
                )}
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="voce@exemplo.com"
                    required
                  />
                </div>
                {mode !== "forgot" && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">Senha</Label>
                      {mode === "login" && (
                        <button
                          type="button"
                          onClick={() => setMode("forgot")}
                          className="text-xs text-primary hover:underline"
                        >
                          Esqueci a senha
                        </button>
                      )}
                    </div>
                    <Input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      minLength={6}
                      required
                    />
                  </div>
                )}
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {mode === "signup"
                    ? "Criar conta"
                    : mode === "forgot"
                      ? "Enviar link"
                      : "Entrar"}
                </Button>
              </form>

              {mode !== "forgot" && (
                <>
                  <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
                    <div className="h-px flex-1 bg-border" />
                    ou
                    <div className="h-px flex-1 bg-border" />
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={handleGoogle}
                    disabled={googleLoading}
                  >
                    {googleLoading ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                        <path
                          fill="currentColor"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.27-4.74 3.27-8.1z"
                        />
                        <path
                          fill="currentColor"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23z"
                          opacity=".7"
                        />
                        <path
                          fill="currentColor"
                          d="M5.84 14.1a6.6 6.6 0 0 1 0-4.2V7.06H2.18a11 11 0 0 0 0 9.88l3.66-2.84z"
                          opacity=".5"
                        />
                        <path
                          fill="currentColor"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15A11 11 0 0 0 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                          opacity=".9"
                        />
                      </svg>
                    )}
                    Continuar com Google
                  </Button>
                </>
              )}

              <p className="mt-6 text-center text-sm text-muted-foreground">
                {mode === "signup" ? (
                  <>
                    Já tem conta?{" "}
                    <button onClick={() => setMode("login")} className="text-primary hover:underline">
                      Entrar
                    </button>
                  </>
                ) : (
                  <>
                    Não tem conta?{" "}
                    <button onClick={() => setMode("signup")} className="text-primary hover:underline">
                      Criar grátis
                    </button>
                  </>
                )}
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
