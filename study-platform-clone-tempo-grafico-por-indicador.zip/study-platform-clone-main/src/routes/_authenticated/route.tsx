import { createFileRoute, Outlet, Link, redirect, useNavigate, useRouterState } from "@tanstack/react-router";
import { Bot, BookOpen, ChevronLeft, ChevronRight, LayoutDashboard, LineChart, LogOut, Plus, Wallet } from "lucide-react";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth", search: { mode: "login" } });
    return { user: data.user };
  },
  component: AuthenticatedLayout,
});

const navItems = [
  { to: "/dashboard", label: "Painel", icon: LayoutDashboard },
  { to: "/bots", label: "Meus bots", icon: Bot },
  { to: "/markets", label: "Mercado", icon: LineChart },
  { to: "/account", label: "Conta", icon: Wallet },
  { to: "/guide", label: "Guia", icon: BookOpen },
] as const;

function AuthenticatedLayout() {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="flex min-h-screen bg-background">
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex flex-col bg-sidebar sidebar-glow transition-[width] duration-200",
          collapsed ? "w-[60px]" : "w-[60px] md:w-[220px]",
        )}
      >
        {/* Logo */}
        <div className="flex h-14 items-center gap-2.5 border-b border-sidebar-border px-3">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-primary">
            <Bot className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className={cn("font-bold text-sm tracking-tight transition-opacity", collapsed ? "hidden" : "hidden md:inline")}>
            BotPilot
          </span>
        </div>

        {/* Nav */}
        <nav className="flex-1 space-y-0.5 px-2 pt-3">
          {navItems.map((item) => {
            const active = pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "group relative flex items-center gap-3 rounded-md px-2.5 py-2 text-[13px] font-medium transition-all",
                  active
                    ? "bg-primary/15 text-primary"
                    : "text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground",
                )}
              >
                {active && (
                  <span className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r-sm bg-primary" />
                )}
                <item.icon className={cn("h-[18px] w-[18px] shrink-0", active ? "text-primary" : "text-sidebar-foreground/50 group-hover:text-sidebar-foreground")} />
                <span className={cn("transition-opacity", collapsed ? "hidden" : "hidden md:inline")}>{item.label}</span>
              </Link>
            );
          })}

          <div className="pt-3">
            <Link
              to="/bots/new"
              className={cn(
                "flex items-center gap-2.5 rounded-md bg-primary px-2.5 py-2 text-[13px] font-semibold text-primary-foreground transition-colors hover:bg-primary/90",
              )}
            >
              <Plus className="h-[18px] w-[18px] shrink-0" />
              <span className={cn("transition-opacity", collapsed ? "hidden" : "hidden md:inline")}>Novo bot</span>
            </Link>
          </div>
        </nav>

        {/* Bottom */}
        <div className="space-y-0.5 border-t border-sidebar-border px-2 py-2">
          <button
            onClick={() => setCollapsed((v) => !v)}
            className="hidden w-full items-center gap-3 rounded-md px-2.5 py-2 text-[13px] font-medium text-sidebar-foreground/50 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground md:flex"
          >
            {collapsed ? <ChevronRight className="h-[18px] w-[18px] shrink-0" /> : <ChevronLeft className="h-[18px] w-[18px] shrink-0" />}
            <span className={cn("transition-opacity", collapsed ? "hidden" : "hidden md:inline")}>Recolher</span>
          </button>
          <button
            onClick={() => {
              void supabase.auth.signOut().then(() => navigate({ to: "/" }));
            }}
            className="flex w-full items-center gap-3 rounded-md px-2.5 py-2 text-[13px] font-medium text-sidebar-foreground/50 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground"
          >
            <LogOut className="h-[18px] w-[18px] shrink-0" />
            <span className={cn("transition-opacity", collapsed ? "hidden" : "hidden md:inline")}>Sair</span>
          </button>
        </div>
      </aside>

      <main className={cn("flex-1 transition-[margin] duration-200", collapsed ? "ml-[60px]" : "ml-[60px] md:ml-[220px]")}>
        <div className="mx-auto max-w-7xl px-4 py-6 md:px-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
