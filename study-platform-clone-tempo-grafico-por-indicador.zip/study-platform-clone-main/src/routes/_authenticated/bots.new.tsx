import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState, type FormEvent, type ReactNode } from "react";
import { ArrowLeft, Bot, Info, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { createBot, SUPPORTED_PAIRS } from "@/lib/bots.functions";
import { getSpotMarkets } from "@/lib/market.functions";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { DcaBotSample } from "@/components/dca-bot-sample";
import { BotEntryFields, initialEntry } from "@/components/bot-entry-fields";
import { CascadingPairSelector } from "@/components/cascading-pair-selector";
import { createBotSchema } from "@/lib/bots.functions";
import { BOT_LIMITS, inputBounds } from "@/lib/bot-limits";
import { describeEntry } from "@/lib/indicators";

export const Route = createFileRoute("/_authenticated/bots/new")({
  head: () => ({
    meta: [
      { title: "Criar bot DCA — BotPilot" },
      { name: "description", content: "Configure uma estratégia DCA para simulação de trading." },
      { property: "og:title", content: "Criar bot DCA — BotPilot" },
      { property: "og:description", content: "Configure uma estratégia DCA para simulação de trading." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NewBotPage,
});

function NewBotPage() {
  const navigate = useNavigate();
  const createBotFn = useServerFn(createBot);
  const fetchMarketsFn = useServerFn(getSpotMarkets);
  const { data: spotMarkets = [] } = useQuery({
    queryKey: ["spot-markets-pair-options"],
    queryFn: () => fetchMarketsFn(),
    staleTime: 60000,
  });

  const binanceSpotUsdtPairs = spotMarkets.length
    ? spotMarkets.map((m) => `${m.base}/USDT`)
    : SUPPORTED_PAIRS;
  const [showSample, setShowSample] = useState(false);
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState("Meu bot DCA");
  const [pairs, setPairs] = useState(["BTC/USDT"]);
  const [baseOrder, setBaseOrder] = useState("100");
  const [safetyOrder, setSafetyOrder] = useState("100");
  const [maxSafetyOrders, setMaxSafetyOrders] = useState("3");
  const [deviation, setDeviation] = useState("1.5");
  const [takeProfit, setTakeProfit] = useState("2");
  const [useStopLoss, setUseStopLoss] = useState(false);
  const [stopLoss, setStopLoss] = useState("10");
  const [start, setStart] = useState(initialEntry());

  const totalAllocation = pairs.length * (Number(baseOrder || 0) + Number(safetyOrder || 0) * Number(maxSafetyOrders || 0));

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setLoading(true);
    try {
      const bot = await createBotFn({
        data: createBotSchema.parse({
          name,
          pair: pairs[0], pairs, timeframe: start.timeframe,
          baseOrderSize: Number(baseOrder),
          safetyOrderSize: Number(safetyOrder),
          maxSafetyOrders: Number(maxSafetyOrders),
          priceDeviationPct: Number(deviation),
          takeProfitPct: Number(takeProfit),
          ...(useStopLoss ? { stopLossPct: Number(stopLoss) } : {}),
          startCondition: start.mode,
          ...(start.mode === "indicator" ? { indicatorConfigs: start.configs } : {}),
        }),
      });
      toast.success("Bot criado e pronto para simular");
      navigate({ to: "/bots/$botId", params: { botId: bot.id } });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível criar o bot");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl">
      <Button variant="ghost" className="mb-5" onClick={() => navigate({ to: "/bots" })}>
        <ArrowLeft className="mr-2 h-4 w-4" />Voltar
      </Button>
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
        <h1 className="text-2xl font-bold tracking-tight">Criar bot DCA</h1>
        <p className="text-sm text-muted-foreground">{showSample ? "Conta demonstrativa · saldo fictício" : "Configure como o bot compra, reduz o preço médio e realiza lucro."}</p>
        </div>
        <Button type="button" variant="outline" onClick={() => setShowSample(!showSample)}>{showSample ? "Abrir simulador atual" : "Ver nova amostra"}</Button>
      </div>

      {showSample ? <DcaBotSample /> : (
      <form onSubmit={submit} className="grid gap-5 lg:grid-cols-[1fr_300px]">
        <div className="space-y-5">
          <Card>
            <CardHeader><CardTitle className="text-base">Informações do bot</CardTitle></CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <Field label="Nome" htmlFor="name"><Input id="name" value={name} onChange={(event) => setName(event.target.value)} required maxLength={60} /></Field>
              <div className="sm:col-span-2">
                <CascadingPairSelector pairs={pairs} options={binanceSpotUsdtPairs} onChange={setPairs} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Condição de início</CardTitle></CardHeader>
            <CardContent><BotEntryFields prefix="new-start" value={start} onChange={setStart} /></CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Ordens DCA</CardTitle></CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <NumberField id="base" label="Ordem base (USDT)" value={baseOrder} setValue={setBaseOrder} {...inputBounds(BOT_LIMITS.orderSize)} />
              <NumberField id="safety" label="Ordem de segurança (USDT)" value={safetyOrder} setValue={setSafetyOrder} {...inputBounds(BOT_LIMITS.orderSize)} />
              <NumberField id="count" label="Máx. ordens de segurança" value={maxSafetyOrders} setValue={setMaxSafetyOrders} {...inputBounds(BOT_LIMITS.maxSafetyOrders)} step="1" />
              <NumberField id="deviation" label="Desvio entre ordens (%)" value={deviation} setValue={setDeviation} {...inputBounds(BOT_LIMITS.priceDeviationPct)} step="0.1" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Saída da operação</CardTitle></CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <NumberField id="profit" label="Take profit (%)" value={takeProfit} setValue={setTakeProfit} {...inputBounds(BOT_LIMITS.takeProfitPct)} step="0.1" />
              <div className="space-y-3">
                <div className="flex h-9 items-center justify-between">
                  <Label htmlFor="use-stop">Usar stop loss</Label>
                  <Switch id="use-stop" checked={useStopLoss} onCheckedChange={setUseStopLoss} />
                </div>
                {useStopLoss && <Input aria-label="Stop loss em porcentagem" type="number" value={stopLoss} onChange={(event) => setStopLoss(event.target.value)} {...inputBounds(BOT_LIMITS.stopLossPct)} step="0.1" required />}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="sticky top-8">
            <CardHeader><CardTitle className="flex items-center gap-2 text-base"><Bot className="h-4 w-4 text-primary" />Resumo</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <SummaryRow label="Par" value={pairs.join(", ")} />
              <SummaryRow label="Estratégia" value="DCA long" />
              <SummaryRow label="Entrada" value={start.mode === "indicator" ? start.configs.map(c => describeEntry(c, start.timeframe)).join(" + ") : "Imediato"} />
              <SummaryRow label="Capital máximo" value={`$${totalAllocation.toFixed(2)}`} />
              <SummaryRow label="Take profit" value={`${Number(takeProfit || 0).toFixed(2)}%`} />
              <div className="flex gap-2 rounded-md bg-accent/60 p-3 text-xs text-accent-foreground"><Info className="mt-0.5 h-4 w-4 shrink-0" />O bot só usa saldo fictício. Nenhuma ordem real será enviada.</div>
              <Button type="submit" className="w-full" disabled={loading || !name.trim()}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Criar bot
              </Button>
            </CardContent>
          </Card>
        </div>
      </form>
      )}
    </div>
  );
}

function Field({ label, htmlFor, children }: { label: string; htmlFor: string; children: ReactNode }) {
  return <div className="space-y-2"><Label htmlFor={htmlFor}>{label}</Label>{children}</div>;
}

function NumberField({ id, label, value, setValue, min, max, step }: { id: string; label: string; value: string; setValue: (value: string) => void; min: string; max?: string; step?: string }) {
  return <Field label={label} htmlFor={id}><Input id={id} type="number" value={value} onChange={(event) => setValue(event.target.value)} min={min} max={max} step={step} required /></Field>;
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-3 text-sm"><span className="text-muted-foreground">{label}</span><span className="min-w-0 break-words font-medium font-mono-num">{value}</span></div>;
}