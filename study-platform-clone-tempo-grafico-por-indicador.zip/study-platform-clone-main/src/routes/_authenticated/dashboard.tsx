import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bot, Play, TrendingDown, TrendingUp, Wallet, Zap } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { runSimulation } from "@/lib/bots.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatUsd, formatPct, pnlColor } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Painel — BotPilot" },
      { name: "description", content: "Visão geral do seu portfólio simulado e bots ativos." },
      { property: "og:title", content: "Painel — BotPilot" },
      { property: "og:description", content: "Visão geral do seu portfólio simulado e bots ativos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { user } = Route.useRouteContext();
  const queryClient = useQueryClient();
  const runSimulationFn = useServerFn(runSimulation);
  const [simulating, setSimulating] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["dashboard", user?.id],
    enabled: !!user,
    queryFn: async () => {
      if (!user) throw new Error("Sessão indisponível");
      const [balances, bots, deals] = await Promise.all([
        supabase.from("paper_balances").select("*").eq("user_id", user.id),
        supabase.from("bots").select("*").eq("user_id", user.id).order("created_at", { ascending: false }),
        supabase.from("deals").select("*").eq("user_id", user.id).order("opened_at", { ascending: false }).limit(10),
      ]);
      return {
        balance: balances.data?.find((b) => b.currency === "USDT"),
        bots: bots.data ?? [],
        deals: deals.data ?? [],
      };
    },
  });

  const handleSimulate = async () => {
    setSimulating(true);
    try {
      const result = await runSimulationFn();
      toast.success(
        `Simulação executada: ${result.opened} deals abertos, ${result.closed} fechados, ${result.safetyOrders} ordens de segurança${result.waiting ? `, ${result.waiting} aguardando indicador` : ""}.`,
      );
      await queryClient.invalidateQueries();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Falha na simulação");
    } finally {
      setSimulating(false);
    }
  };

  const activeBots = data?.bots.filter((b) => b.status === "active") ?? [];
  const openDeals = data?.deals.filter((d) => d.status === "open") ?? [];
  const totalProfit = data?.bots.reduce((acc, b) => acc + Number(b.total_profit), 0) ?? 0;

  return (
    <div>
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Painel</h1>
          <p className="text-sm text-muted-foreground">Visão geral do seu portfólio simulado</p>
        </div>
        <Button onClick={handleSimulate} disabled={simulating}>
          <Play className="mr-2 h-4 w-4" />
          {simulating ? "Simulando..." : "Rodar simulação"}
        </Button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Saldo disponível"
          icon={Wallet}
          loading={isLoading}
          value={formatUsd(Number(data?.balance?.balance ?? 0))}
          hint="USDT fictício"
          accent="default"
        />
        <StatCard
          title="Lucro total"
          icon={totalProfit >= 0 ? TrendingUp : TrendingDown}
          loading={isLoading}
          value={formatUsd(totalProfit)}
          valueClass={pnlColor(totalProfit)}
          hint="Soma de todos os bots"
          accent={totalProfit >= 0 ? "profit" : "loss"}
        />
        <StatCard
          title="Bots ativos"
          icon={Bot}
          loading={isLoading}
          value={String(activeBots.length)}
          hint={`${data?.bots.length ?? 0} no total`}
          accent="primary"
        />
        <StatCard
          title="Deals abertos"
          icon={Zap}
          loading={isLoading}
          value={String(openDeals.length)}
          hint="Aguardando take profit"
          accent="default"
        />
      </div>

      <div className="mt-6 grid gap-3 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between border-b border-border pb-3">
            <CardTitle className="text-sm font-semibold">Meus bots</CardTitle>
            <Link to="/bots" className="text-xs font-medium text-primary hover:underline">
              Ver todos →
            </Link>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
              </div>
            ) : data?.bots.length ? (
              <ul className="divide-y divide-border">
                {data.bots.slice(0, 5).map((bot) => (
                  <li key={bot.id}>
                    <Link
                      to="/bots/$botId"
                      params={{ botId: bot.id }}
                      className="flex items-center justify-between py-3 transition-colors hover:bg-accent/50"
                    >
                      <div>
                        <p className="text-sm font-medium">{bot.name}</p>
                        <p className="text-xs text-muted-foreground font-mono-num">{bot.pair}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`text-sm font-mono-num ${pnlColor(Number(bot.total_profit))}`}>
                          {formatUsd(Number(bot.total_profit))}
                        </span>
                        <StatusBadge status={bot.status} />
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState
                text="Você ainda não tem bots. Crie o primeiro para começar a simular."
                cta="Criar bot"
                to="/bots/new"
              />
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="border-b border-border pb-3">
            <CardTitle className="text-sm font-semibold">Deals recentes</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
              </div>
            ) : data?.deals.length ? (
              <ul className="divide-y divide-border">
                {data.deals.map((deal) => (
                  <li key={deal.id} className="flex items-center justify-between py-3">
                    <div>
                      <p className="text-sm font-medium font-mono-num">{deal.pair}</p>
                      <p className="text-xs text-muted-foreground">
                        Entrada {formatUsd(Number(deal.entry_price))}
                      </p>
                    </div>
                    <div className="text-right">
                      {deal.status === "completed" ? (
                        <span className={`text-sm font-mono-num ${pnlColor(Number(deal.profit))}`}>
                          {formatUsd(Number(deal.profit))}
                        </span>
                      ) : (
                        <Badge variant="secondary">Aberto</Badge>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState
                text="Nenhum deal ainda. Rode a simulação com um bot ativo."
                cta="Ir para bots"
                to="/bots"
              />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({
  title,
  value,
  hint,
  icon: Icon,
  loading,
  valueClass,
  accent = "default",
}: {
  title: string;
  value: string;
  hint: string;
  icon: typeof Wallet;
  loading: boolean;
  valueClass?: string;
  accent?: "default" | "profit" | "loss" | "primary";
}) {
  const iconBg = accent === "profit" ? "bg-profit/15 text-profit" : accent === "loss" ? "bg-loss/15 text-loss" : accent === "primary" ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground";
  return (
    <Card className="border-border/60 bg-card/80">
      <CardContent className="pt-5 pb-4">
        <div className="flex items-center justify-between">
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{title}</p>
          <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${iconBg}`}>
            <Icon className="h-4 w-4" />
          </div>
        </div>
        {loading ? (
          <Skeleton className="mt-3 h-8 w-24" />
        ) : (
          <p className={`mt-3 text-2xl font-bold font-mono-num ${valueClass ?? ""}`}>{value}</p>
        )}
        <p className="mt-1.5 text-[11px] text-muted-foreground">{hint}</p>
      </CardContent>
    </Card>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; className: string; dot: string }> = {
    active: { label: "Ativo", className: "bg-profit/10 text-profit border-profit/25", dot: "bg-profit" },
    paused: { label: "Pausado", className: "bg-secondary text-secondary-foreground border-secondary", dot: "bg-muted-foreground" },
    stopped: { label: "Parado", className: "bg-destructive/10 text-destructive border-destructive/25", dot: "bg-destructive" },
  };
  const s = map[status] ?? { label: "Parado", className: "bg-destructive/10 text-destructive border-destructive/25", dot: "bg-destructive" };
  return (
    <Badge variant="outline" className={`gap-1.5 ${s.className}`}>
      <span className={`inline-block h-1.5 w-1.5 rounded-full ${s.dot}`} />
      {s.label}
    </Badge>
  );
}

function EmptyState({ text, cta, to }: { text: string; cta: string; to: string }) {
  return (
    <div className="py-8 text-center">
      <p className="text-sm text-muted-foreground">{text}</p>
      <Link to={to}>
        <Button variant="outline" size="sm" className="mt-4">
          {cta}
        </Button>
      </Link>
    </div>
  );
}

export { formatPct };
