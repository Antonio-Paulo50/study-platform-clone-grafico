import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, type FormEvent } from "react";
import { Pencil, Plus, RotateCcw, ShieldCheck, Wallet } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  getPaperAccount,
  managePaperAccount,
  paperActionSchema,
} from "@/lib/paper-account.functions";
import { formatUsd } from "@/lib/format";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({
    meta: [
      { title: "Conta & Saldos Simulados — BotPilot" },
      {
        name: "description",
        content:
          "Gerencie sua conta de simulação, adicione fundos fictícios e redefina o saldo para testes.",
      },
      { property: "og:title", content: "Conta & Saldos Simulados — BotPilot" },
      {
        property: "og:description",
        content:
          "Gerencie sua conta de simulação, adicione fundos fictícios e redefina o saldo para testes.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AccountPage,
});

type Dialogs = "funds" | "rename" | "reset" | null;

function AccountPage() {
  const queryClient = useQueryClient();
  const getAccountFn = useServerFn(getPaperAccount);
  const manageFn = useServerFn(managePaperAccount);

  const [dialog, setDialog] = useState<Dialogs>(null);
  const [fundsAmount, setFundsAmount] = useState("1000");
  const [editName, setEditName] = useState("");
  const [resetText, setResetText] = useState("");
  const [loading, setLoading] = useState(false);

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ["paper-account"],
    queryFn: () => getAccountFn(),
  });

  const closeDialog = () => {
    setDialog(null);
    setResetText("");
  };

  const runAction = async (payload: unknown, successMsg: string) => {
    setLoading(true);
    try {
      const parsed = paperActionSchema.parse(payload);
      await manageFn({ data: parsed });
      await queryClient.invalidateQueries({ queryKey: ["paper-account"] });
      await queryClient.invalidateQueries({ queryKey: ["dashboard"] });
      await queryClient.invalidateQueries({ queryKey: ["bots"] });
      await refetch();
      toast.success(successMsg);
      closeDialog();
    } catch (err) {
      toast.error(err instanceof Error && err.message ? err.message : "Erro ao executar ação");
    } finally {
      setLoading(false);
    }
  };

  const handleAddFunds = (e: FormEvent) => {
    e.preventDefault();
    void runAction({ action: "add", amount: Number(fundsAmount) }, "Fundos fictícios adicionados!");
  };

  const handleRename = (e: FormEvent) => {
    e.preventDefault();
    void runAction({ action: "rename", name: editName }, "Conta renomeada com sucesso!");
  };

  const handleReset = (e: FormEvent) => {
    e.preventDefault();
    void runAction(
      { action: "reset", confirmation: resetText.trim() },
      "Conta restaurada para $10.000!",
    );
  };

  const accountName = data?.name ?? "Conta de simulação";
  const balance = Number(data?.balance ?? 0);
  const invested = Number(data?.invested ?? 0);
  const historyCount = Number(data?.historyCount ?? 0);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Conta & Carteiras</h1>
          <p className="text-sm text-muted-foreground">
            Simulação Paper Trading estilo 3Commas com isolamento total de risco
          </p>
        </div>
        <Button onClick={() => setDialog("funds")} className="gap-2 font-medium">
          <Plus className="h-4 w-4" /> Adicionar fundos
        </Button>
      </div>

      {isError && (
        <p className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
          Não foi possível carregar a conta.{" "}
          <button type="button" className="underline" onClick={() => void refetch()}>
            Tentar novamente
          </button>
        </p>
      )}

      {/* Balance Overview Card */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-border/60 bg-card/80 md:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base font-semibold text-muted-foreground">
                Saldo (USDT)
              </CardTitle>
              <Badge
                variant="outline"
                className="border-primary/30 bg-primary/10 text-primary gap-1"
              >
                <ShieldCheck className="h-3 w-3" /> 100% Simulado
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap items-baseline gap-3">
              <span className="text-4xl font-extrabold tracking-tight font-mono-num text-foreground">
                {isLoading ? "..." : formatUsd(balance)}
              </span>
              <span className="text-xs text-muted-foreground">
                Conta: <strong className="text-foreground">{accountName}</strong>
              </span>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              Todo lucro, perda e ordens safety DCA são contabilizados exclusivamente neste saldo
              simulado.
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/60 bg-card/80 flex flex-col justify-between">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold text-muted-foreground">
              Ações Rápidas
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button
              variant="outline"
              size="sm"
              className="w-full justify-start gap-2 border-border/80"
              onClick={() => setDialog("reset")}
              disabled={loading}
            >
              <RotateCcw className="h-3.5 w-3.5 text-muted-foreground" />
              Restaurar para $10.000
            </Button>
            <Button
              variant="outline"
              size="sm"
              asChild
              className="w-full justify-start gap-2 border-border/80"
            >
              <Link to="/bots/new">
                <Plus className="h-3.5 w-3.5 text-primary" />
                Criar Bot nesta Conta
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Account */}
      <Card className="border-border/60 bg-card/80">
        <CardHeader className="border-b border-border/60 pb-3">
          <CardTitle className="text-base font-semibold">Conta Paper Trading</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="flex flex-wrap items-center justify-between gap-4 bg-primary/5 p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 text-primary">
                <Wallet className="h-5 w-5" />
              </div>
              <div>
                <span className="font-semibold text-foreground">{accountName}</span>
                <div className="text-xs text-muted-foreground font-mono-num">
                  Saldo: {formatUsd(balance)} · Investido em negociações abertas:{" "}
                  {formatUsd(invested)} · {historyCount} negociação(ões) no histórico
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-foreground"
                aria-label="Renomear"
                onClick={() => {
                  setEditName(accountName);
                  setDialog("rename");
                }}
              >
                <Pencil className="h-3.5 w-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-destructive"
                aria-label="Restaurar saldo"
                onClick={() => setDialog("reset")}
                disabled={loading}
              >
                <RotateCcw className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Add funds dialog */}
      <Dialog open={dialog === "funds"} onOpenChange={(v) => !v && closeDialog()}>
        <DialogContent className="max-w-md bg-card border-border/80">
          <DialogHeader>
            <DialogTitle>Adicionar fundos fictícios</DialogTitle>
            <DialogDescription>
              Soma o valor ao saldo simulado em USDT. Nenhum dinheiro real é usado.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddFunds} className="space-y-4 pt-2">
            <div className="space-y-1.5">
              <Label htmlFor="fundsAmount">Valor em USDT</Label>
              <Input
                id="fundsAmount"
                type="number"
                min="1"
                max="1000000"
                step="any"
                value={fundsAmount}
                onChange={(e) => setFundsAmount(e.target.value)}
                required
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="ghost" onClick={closeDialog}>
                Cancelar
              </Button>
              <Button type="submit" disabled={loading || !(Number(fundsAmount) >= 1)}>
                {loading ? "Adicionando..." : "Adicionar"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Rename dialog */}
      <Dialog open={dialog === "rename"} onOpenChange={(v) => !v && closeDialog()}>
        <DialogContent className="max-w-sm bg-card border-border/80">
          <DialogHeader>
            <DialogTitle>Renomear Conta</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleRename} className="space-y-4 pt-2">
            <div className="space-y-1.5">
              <Label htmlFor="editName">Novo nome</Label>
              <Input
                id="editName"
                value={editName}
                maxLength={60}
                onChange={(e) => setEditName(e.target.value)}
                required
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={closeDialog}>
                Cancelar
              </Button>
              <Button type="submit" disabled={loading || !editName.trim()}>
                Salvar
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Reset dialog */}
      <Dialog open={dialog === "reset"} onOpenChange={(v) => !v && closeDialog()}>
        <DialogContent className="max-w-md bg-card border-border/80">
          <DialogHeader>
            <DialogTitle>Restaurar conta para $10.000</DialogTitle>
            <DialogDescription>
              Isso apaga todo o histórico de negociações, zera o lucro dos bots, pausa todos eles e
              volta o saldo para 10.000 USDT. Não dá para desfazer.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleReset} className="space-y-4 pt-2">
            <div className="space-y-1.5">
              <Label htmlFor="resetText">
                Digite <strong>RESETAR</strong> para confirmar
              </Label>
              <Input
                id="resetText"
                value={resetText}
                onChange={(e) => setResetText(e.target.value)}
                autoComplete="off"
                required
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={closeDialog}>
                Cancelar
              </Button>
              <Button
                type="submit"
                variant="destructive"
                disabled={loading || resetText.trim() !== "RESETAR"}
              >
                {loading ? "Restaurando..." : "Restaurar conta"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
