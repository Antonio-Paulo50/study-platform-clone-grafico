import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bot, MoreVertical, Pause, Play, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { deleteBot, setBotStatus } from "@/lib/bots.functions";
import { formatUsd, pnlColor } from "@/lib/format";
import { StatusBadge } from "./dashboard";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export const Route = createFileRoute("/_authenticated/bots/")({
  head: () => ({
    meta: [
      { title: "Meus bots DCA — BotPilot" },
      { name: "description", content: "Gerencie seus bots de trading DCA e acompanhe resultados simulados." },
      { property: "og:title", content: "Meus bots DCA — BotPilot" },
      { property: "og:description", content: "Gerencie seus bots de trading DCA e acompanhe resultados simulados." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: BotsPage,
});

function BotsPage() {
  const { user } = Route.useRouteContext();
  const queryClient = useQueryClient();
  const setStatusFn = useServerFn(setBotStatus);
  const deleteBotFn = useServerFn(deleteBot);
  const [search, setSearch] = useState("");
  const { data = [], isLoading } = useQuery({
    queryKey: ["bots", user.id],
    queryFn: async () => {
      const { data: bots, error } = await supabase.from("bots").select("*").eq("user_id", user.id).order("created_at", { ascending: false });
      if (error) throw error;
      return bots;
    },
  });

  const updateStatus = async (botId: string, status: "active" | "paused") => {
    try {
      await setStatusFn({ data: { botId, status } });
      await queryClient.invalidateQueries({ queryKey: ["bots"] });
      toast.success(status === "active" ? "Bot ativado" : "Bot pausado");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível atualizar o bot");
    }
  };

  const remove = async (botId: string) => {
    if (!window.confirm("Excluir este bot e todo o histórico de deals?")) return;
    try {
      await deleteBotFn({ data: { botId } });
      await queryClient.invalidateQueries({ queryKey: ["bots"] });
      toast.success("Bot excluído");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível excluir o bot");
    }
  };

  const filtered = useMemo(() => {
    if (!search.trim()) return data;
    const q = search.toLowerCase();
    return data.filter((b) => b.name.toLowerCase().includes(q) || b.pair.toLowerCase().includes(q) || b.pairs.some((p) => p.toLowerCase().includes(q)));
  }, [data, search]);

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Meus bots</h1>
          <p className="text-sm text-muted-foreground">Estratégias DCA usando apenas saldo fictício</p>
        </div>
        <Button asChild>
          <Link to="/bots/new"><Plus className="mr-2 h-4 w-4" />Novo bot</Link>
        </Button>
      </div>
      {data.length > 0 && (
        <div className="mb-5 flex items-center gap-3">
          <div className="relative w-full max-w-xs">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input className="pl-9" placeholder="Buscar por nome ou par…" maxLength={40} value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <span className="text-xs text-muted-foreground">{filtered.length} de {data.length} bots</span>
        </div>
      )}

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 3 }, (_, index) => <Skeleton key={index} className="h-56" />)}
        </div>
      ) : data.length ? (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((bot) => (
            <Card key={bot.id} className="border-border/60 bg-card/80 transition-all hover:border-primary/40 hover:shadow-md hover:shadow-primary/5">
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <Link to="/bots/$botId" params={{ botId: bot.id }} className="min-w-0 flex-1">
                    <div className="flex items-center gap-3">
                      <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/15">
                        <Bot className="h-5 w-5 text-primary" />
                        {bot.status === "active" && <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-card bg-profit" />}
                      </div>
                      <div className="min-w-0">
                        <p className="truncate font-semibold">{bot.name}</p>
                        <p className="break-words text-xs text-muted-foreground font-mono-num">{(bot.pairs.length ? bot.pairs : [bot.pair]).join(", ")} · DCA</p>
                      </div>
                    </div>
                  </Link>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild><Button variant="ghost" size="icon" aria-label="Ações do bot"><MoreVertical className="h-4 w-4" /></Button></DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      {bot.status === "active" ? (
                        <DropdownMenuItem onClick={() => void updateStatus(bot.id, "paused")}><Pause className="mr-2 h-4 w-4" />Pausar</DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem onClick={() => void updateStatus(bot.id, "active")}><Play className="mr-2 h-4 w-4" />Ativar</DropdownMenuItem>
                      )}
                      <DropdownMenuItem onClick={() => void remove(bot.id)} className="text-destructive"><Trash2 className="mr-2 h-4 w-4" />Excluir</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <div className="mt-5 grid grid-cols-3 gap-3 border-t border-border/60 pt-4">
                  <div><p className="text-[11px] uppercase tracking-wider text-muted-foreground">Base</p><p className="mt-1 text-sm font-semibold font-mono-num">{formatUsd(Number(bot.base_order_size))}</p></div>
                  <div><p className="text-[11px] uppercase tracking-wider text-muted-foreground">TP</p><p className="mt-1 text-sm font-semibold font-mono-num">{Number(bot.take_profit_pct).toFixed(2)}%</p></div>
                  <div className="text-right"><p className="text-[11px] uppercase tracking-wider text-muted-foreground">Lucro</p><p className={`mt-1 text-sm font-semibold font-mono-num ${pnlColor(Number(bot.total_profit))}`}>{formatUsd(Number(bot.total_profit))}</p></div>
                </div>
                <div className="mt-3 flex justify-end"><StatusBadge status={bot.status} /></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex min-h-72 flex-col items-center justify-center rounded-lg border border-dashed border-border bg-card/40 px-6 text-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/15"><Bot className="h-6 w-6 text-primary" /></div>
          <h2 className="mt-4 font-semibold">Nenhum bot criado</h2>
          <p className="mt-2 max-w-sm text-sm text-muted-foreground">Monte sua primeira estratégia DCA e teste com saldo fictício.</p>
          <Button asChild className="mt-5"><Link to="/bots/new"><Plus className="mr-2 h-4 w-4" />Criar primeiro bot</Link></Button>
        </div>
      )}
    </div>
  );
}