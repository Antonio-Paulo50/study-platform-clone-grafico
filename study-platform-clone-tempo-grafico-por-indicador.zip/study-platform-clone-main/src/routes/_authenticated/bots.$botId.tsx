import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Bot, Pause, Play, Trash2, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { deleteBot, setBotStatus } from "@/lib/bots.functions";
import { getPriceHistory } from "@/lib/market.functions";
import { formatPct, formatUsd, pnlColor } from "@/lib/format";
import { StatusBadge } from "./dashboard";
import { EditBotDialog } from "@/components/edit-bot-dialog";
import { describeEntry, indicatorConfigSchema, indicatorConfigsSchema, TIMEFRAMES, timeframeSchema } from "@/lib/indicators";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";

const pairCoinIds: Record<string, string> = {
  "BTC/USDT": "bitcoin", "ETH/USDT": "ethereum", "BNB/USDT": "binancecoin", "SOL/USDT": "solana", "XRP/USDT": "ripple",
  "ADA/USDT": "cardano", "DOGE/USDT": "dogecoin", "AVAX/USDT": "avalanche-2", "LINK/USDT": "chainlink", "DOT/USDT": "polkadot",
};
const chartConfig = { price: { label: "Preço", color: "var(--color-chart-1)" } } satisfies ChartConfig;

export const Route = createFileRoute("/_authenticated/bots/$botId")({
  head: () => ({
    meta: [
      { title: "Detalhes do bot — BotPilot" },
      { name: "description", content: "Acompanhe a configuração, desempenho e deals do seu bot DCA." },
      { property: "og:title", content: "Detalhes do bot — BotPilot" },
      { property: "og:description", content: "Acompanhe a configuração, desempenho e deals do seu bot DCA." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: BotDetailPage,
});

function BotDetailPage() {
  const { botId } = Route.useParams();
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const setStatusFn = useServerFn(setBotStatus);
  const deleteBotFn = useServerFn(deleteBot);
  const getHistoryFn = useServerFn(getPriceHistory);

  const { data, isLoading } = useQuery({
    queryKey: ["bot-detail", botId],
    queryFn: async () => {
      const [botResult, dealsResult] = await Promise.all([
        supabase.from("bots").select("*").eq("id", botId).eq("user_id", user.id).single(),
        supabase.from("deals").select("*").eq("bot_id", botId).eq("user_id", user.id).order("opened_at", { ascending: false }),
      ]);
      if (botResult.error) throw botResult.error;
      if (dealsResult.error) throw dealsResult.error;
      return { bot: botResult.data, deals: dealsResult.data };
    },
  });

  const coinId = data ? pairCoinIds[data.bot.pair] : undefined;
  const { data: history = [] } = useQuery({
    queryKey: ["price-history", coinId],
    enabled: !!coinId,
    queryFn: () => {
      if (!coinId) throw new Error("Moeda não suportada");
      return getHistoryFn({ data: { coinId, days: 7 } });
    },
    staleTime: 120_000,
  });
  const chartData = history.map((point) => ({ date: new Date(point.time).toLocaleDateString("pt-BR", { day: "2-digit", month: "short" }), price: point.price }));

  if (isLoading) return <div className="space-y-4"><Skeleton className="h-10 w-64" /><Skeleton className="h-80 w-full" /></div>;
  if (!data) return <div className="py-20 text-center"><p className="text-muted-foreground">Bot não encontrado.</p><Button asChild variant="outline" className="mt-4"><Link to="/bots">Voltar aos bots</Link></Button></div>;

  const bot = data.bot;
  const conditions = indicatorConfigsSchema.safeParse(bot.indicator_configs);
  const legacy = indicatorConfigSchema.safeParse(bot.indicator_config);
  const interval = timeframeSchema.safeParse(bot.timeframe);
  const botTf = interval.success ? interval.data : "1h";
  const descriptions = conditions.success ? conditions.data.map(c => describeEntry(c, botTf)) : legacy.success ? [describeEntry(legacy.data, botTf)] : ["Configuração inválida"];
  const completed = data.deals.filter((deal) => deal.status === "completed");
  const investedOpen = data.deals.filter((deal) => deal.status === "open").reduce((sum, deal) => sum + Number(deal.invested), 0);

  const changeStatus = async () => {
    const status = bot.status === "active" ? "paused" : "active";
    await setStatusFn({ data: { botId, status } });
    await queryClient.invalidateQueries({ queryKey: ["bot-detail", botId] });
    toast.success(status === "active" ? "Bot ativado" : "Bot pausado");
  };
  const remove = async () => {
    if (!window.confirm("Excluir este bot e todo o histórico?")) return;
    await deleteBotFn({ data: { botId } });
    toast.success("Bot excluído");
    navigate({ to: "/bots" });
  };

  return (
    <div>
      <Button variant="ghost" className="mb-5" onClick={() => navigate({ to: "/bots" })}><ArrowLeft className="mr-2 h-4 w-4" />Voltar</Button>
      <div className="mb-8 flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/15"><Bot className="h-6 w-6 text-primary" /></div>
          <div><div className="flex items-center gap-3"><h1 className="text-2xl font-bold tracking-tight">{bot.name}</h1><StatusBadge status={bot.status} /></div><p className="text-sm text-muted-foreground font-mono-num">{(bot.pairs.length ? bot.pairs : [bot.pair]).join(", ")} · DCA long</p></div>
        </div>
        <div className="flex gap-2">
          <EditBotDialog bot={{ ...bot, base_order_size: Number(bot.base_order_size), safety_order_size: Number(bot.safety_order_size), price_deviation_pct: Number(bot.price_deviation_pct), take_profit_pct: Number(bot.take_profit_pct), stop_loss_pct: bot.stop_loss_pct == null ? null : Number(bot.stop_loss_pct) }} hasOpenDeal={data.deals.some((deal) => deal.status === "open")} />
          <Button variant="outline" onClick={() => void changeStatus()}>{bot.status === "active" ? <Pause className="mr-2 h-4 w-4" /> : <Play className="mr-2 h-4 w-4" />}{bot.status === "active" ? "Pausar" : "Ativar"}</Button>
          <Button variant="destructive" size="icon" onClick={() => void remove()} aria-label="Excluir bot"><Trash2 className="h-4 w-4" /></Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Metric label="Lucro realizado" value={formatUsd(Number(bot.total_profit))} className={pnlColor(Number(bot.total_profit))} />
        <Metric label="Deals concluídos" value={String(completed.length)} />
        <Metric label="Capital em deals" value={formatUsd(investedOpen)} />
        <Metric label="Take profit" value={formatPct(Number(bot.take_profit_pct))} />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_320px]">
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2 text-base"><TrendingUp className="h-4 w-4 text-primary" />Preço — últimos 7 dias</CardTitle></CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-72 w-full aspect-auto">
              <AreaChart data={chartData} margin={{ left: 4, right: 4 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" />
                <XAxis dataKey="date" tickLine={false} axisLine={false} minTickGap={28} />
                <YAxis tickLine={false} axisLine={false} width={70} tickFormatter={(value) => `$${Number(value).toLocaleString("en-US", { notation: "compact" })}`} />
                <ChartTooltip content={<ChartTooltipContent formatter={(value) => <span className="font-mono-num">{formatUsd(Number(value))}</span>} />} />
                <Area type="monotone" dataKey="price" stroke="var(--color-chart-1)" fill="var(--color-chart-1)" fillOpacity={0.1} strokeWidth={2} dot={false} />
              </AreaChart>
            </ChartContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Configuração</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <ConfigRow label="Entrada" value={bot.start_condition === "indicator" ? descriptions.join(" + ") : "Imediato"} />
            {bot.start_condition !== "indicator" && <ConfigRow label="Intervalo" value={interval.success ? TIMEFRAMES[interval.data] : "1 hora"} />}
            <ConfigRow label="Ordem base" value={formatUsd(Number(bot.base_order_size))} />
            <ConfigRow label="Ordem de segurança" value={formatUsd(Number(bot.safety_order_size))} />
            <ConfigRow label="Máx. seguranças" value={String(bot.max_safety_orders)} />
            <ConfigRow label="Desvio" value={formatPct(Number(bot.price_deviation_pct))} />
            <ConfigRow label="Take profit" value={formatPct(Number(bot.take_profit_pct))} />
            <ConfigRow label="Stop loss" value={bot.stop_loss_pct == null ? "Desativado" : formatPct(Number(bot.stop_loss_pct))} />
          </CardContent>
        </Card>
      </div>

      <Card className="mt-5">
        <CardHeader><CardTitle className="text-base">Histórico de deals</CardTitle></CardHeader>
        <CardContent className="p-0">
          {data.deals.length ? (
            <div className="overflow-x-auto"><table className="w-full min-w-[700px] text-left text-sm"><thead className="border-b border-border text-xs uppercase text-muted-foreground"><tr><th className="px-5 py-3 font-medium">Par</th><th className="px-5 py-3 font-medium">Status</th><th className="px-5 py-3 font-medium">Entrada</th><th className="px-5 py-3 font-medium">Saída</th><th className="px-5 py-3 font-medium">Investido</th><th className="px-5 py-3 font-medium">Seguranças</th><th className="px-5 py-3 text-right font-medium">Resultado</th></tr></thead><tbody className="divide-y divide-border">{data.deals.map((deal) => <tr key={deal.id}><td className="px-5 py-4 font-mono-num">{deal.pair}</td><td className="px-5 py-4"><StatusBadge status={deal.status === "open" ? "active" : "stopped"} /></td><td className="px-5 py-4 font-mono-num">{formatUsd(Number(deal.entry_price))}</td><td className="px-5 py-4 font-mono-num">{deal.close_price == null ? "—" : formatUsd(Number(deal.close_price))}</td><td className="px-5 py-4 font-mono-num">{formatUsd(Number(deal.invested))}</td><td className="px-5 py-4 font-mono-num">{deal.safety_orders_used}</td><td className={`px-5 py-4 text-right font-mono-num ${pnlColor(Number(deal.profit))}`}>{deal.status === "open" ? "Em andamento" : formatUsd(Number(deal.profit))}</td></tr>)}</tbody></table></div>
          ) : <p className="px-5 py-10 text-center text-sm text-muted-foreground">Nenhum deal ainda. Rode a simulação no painel para abrir o primeiro.</p>}
        </CardContent>
      </Card>
    </div>
  );
}

function Metric({ label, value, className = "" }: { label: string; value: string; className?: string }) {
  return <Card><CardContent className="pt-5"><p className="text-xs text-muted-foreground">{label}</p><p className={`mt-2 text-xl font-semibold font-mono-num ${className}`}>{value}</p></CardContent></Card>;
}
function ConfigRow({ label, value }: { label: string; value: string }) {
  return <div className="grid grid-cols-[90px_minmax(0,1fr)] items-start gap-3 border-b border-border pb-3 text-sm last:border-0 last:pb-0"><span className="text-muted-foreground">{label}</span><span className="break-words text-right font-medium font-mono-num">{value}</span></div>;
}