import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { ArrowDownUp, RefreshCw, Search, Star, TrendingUp } from "lucide-react";
import { useMemo, useEffect, useState } from "react";
import { getSpotMarkets, getOrderBook } from "@/lib/market.functions";
import { formatCompact, formatPct, pnlColor } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/markets")({
  head: () => ({
    meta: [
      { title: "Mercado Spot USDT — BotPilot" },
      { name: "description", content: "Preços, variação, volume e livro de ordens dos pares spot USDT da Binance." },
      { property: "og:title", content: "Mercado Spot USDT — BotPilot" },
      { property: "og:description", content: "Acompanhe pares USDT, favoritos, altas, baixas e ofertas reais de compra e venda." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MarketsPage,
});

const price = (v: number) => v.toLocaleString("en-US", { maximumFractionDigits: v < 1 ? 8 : 4 });

function MarketsPage() {
  const fetchMarkets = useServerFn(getSpotMarkets);
  const fetchBook = useServerFn(getOrderBook);
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState("all");
  const [favorites, setFavorites] = useState<string[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [sort, setSort] = useState("volume");
  const [ascending, setAscending] = useState(false);
  const [limit, setLimit] = useState(50);

  useEffect(() => {
    try {
      const value: unknown = JSON.parse(localStorage.getItem("botpilot-market-favorites") ?? "[]");
      if (Array.isArray(value)) setFavorites(value.filter((s): s is string => typeof s === "string"));
    } catch {
      /* keep empty */
    }
  }, []);

  const toggle = (symbol: string) => {
    const next = favorites.includes(symbol) ? favorites.filter((s) => s !== symbol) : [...favorites, symbol];
    setFavorites(next);
    localStorage.setItem("botpilot-market-favorites", JSON.stringify(next));
  };

  const { data = [], isFetching, error, refetch, dataUpdatedAt } = useQuery({
    queryKey: ["spot-markets"],
    queryFn: fetchMarkets,
    refetchInterval: 15000,
    staleTime: 10000,
  });

  const book = useQuery({
    queryKey: ["order-book", selected],
    queryFn: () => {
      if (!selected) throw new Error("Selecione um par");
      return fetchBook({ data: { symbol: selected } });
    },
    enabled: !!selected,
    refetchInterval: 5000,
  });

  const filtered = useMemo(
    () =>
      data
        .filter(
          (v) =>
            v.symbol.includes(search.toUpperCase().replace("/", "")) &&
            (tab !== "favorites" || favorites.includes(v.symbol)) &&
            (tab !== "gainers" || v.priceChangePercent > 0) &&
            (tab !== "losers" || v.priceChangePercent < 0),
        )
        .sort(
          (a, b) =>
            (ascending ? 1 : -1) *
            (sort === "name"
              ? a.base.localeCompare(b.base)
              : sort === "price"
                ? a.lastPrice - b.lastPrice
                : sort === "change"
                  ? a.priceChangePercent - b.priceChangePercent
                  : a.quoteVolume - b.quoteVolume),
        ),
    [data, search, tab, favorites, sort, ascending],
  );

  const sortBy = (value: string) => {
    setAscending(sort === value ? !ascending : value === "name");
    setSort(value);
  };

  const winners = [...data].sort((a, b) => b.priceChangePercent - a.priceChangePercent);
  const totalVolume = data.reduce((sum, v) => sum + v.quoteVolume, 0);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Mercado USDT</h1>
          <p className="text-sm text-muted-foreground">Cotações ao vivo via Binance Spot</p>
        </div>
        <Button
          variant="outline"
          size="sm"
          disabled={isFetching}
          onClick={() => void refetch()}
          className="gap-2 border-border/80"
        >
          <RefreshCw className={isFetching ? "h-3.5 w-3.5 animate-spin" : "h-3.5 w-3.5"} />
          {isFetching ? "Atualizando..." : "Atualizar"}
        </Button>
      </div>

      {/* 3Commas Top Metric Cards */}
      <div className="grid gap-3 sm:grid-cols-3">
        <Card className="border-border/60 bg-card/80">
          <CardContent className="pt-5 pb-4">
            <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Volume 24h Spot</p>
            <p className="mt-2 text-2xl font-bold font-mono-num">{formatCompact(totalVolume)} <span className="text-xs text-muted-foreground font-sans">USDT</span></p>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/80">
          <CardContent className="pt-5 pb-4">
            <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Maior Alta 24h</p>
            <p className="mt-2 text-2xl font-bold font-mono-num flex items-center gap-2">
              {winners[0]?.base ?? "—"}
              {winners[0] && (
                <span className="text-sm font-semibold text-profit">
                  {formatPct(winners[0].priceChangePercent)}
                </span>
              )}
            </p>
          </CardContent>
        </Card>
        <Card className="border-border/60 bg-card/80">
          <CardContent className="pt-5 pb-4">
            <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Pares Ativos</p>
            <p className="mt-2 text-2xl font-bold font-mono-num">{data.length || "—"}</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <Tabs
          value={tab}
          onValueChange={(v) => {
            setTab(v);
            setLimit(50);
            if (v === "gainers" || v === "losers") {
              setSort("change");
              setAscending(v === "losers");
            }
          }}
        >
          <TabsList className="bg-card border border-border/80">
            <TabsTrigger value="all">Todos</TabsTrigger>
            <TabsTrigger value="favorites" className="gap-1">
              <Star className="h-3 w-3" /> Favoritos
            </TabsTrigger>
            <TabsTrigger value="gainers">Altas</TabsTrigger>
            <TabsTrigger value="losers">Baixas</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            className="h-9 pl-9 bg-card border-border/80 text-sm"
            placeholder="Buscar par..."
            maxLength={30}
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setLimit(50);
            }}
          />
        </div>
      </div>

      {/* Table Container */}
      <div className="rounded-lg border border-border/60 bg-card/80 overflow-hidden shadow-sm">
        <div className="flex items-center justify-between border-b border-border/60 px-4 py-2.5 text-xs text-muted-foreground">
          <span className="font-semibold text-primary">{filtered.length} pares encontrados</span>
          <span>{dataUpdatedAt ? `Atualizado ${new Date(dataUpdatedAt).toLocaleTimeString("pt-BR")}` : "Carregando..."}</span>
        </div>

        {error && <p role="alert" className="p-4 text-sm text-loss">Mercado indisponível. Tente novamente.</p>}

        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-left text-sm">
            <thead className="border-b border-border/60 bg-muted/20 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="w-10 px-3 py-3"></th>
                <th className="px-4 py-3 font-medium">
                  <button className="flex items-center gap-1 hover:text-foreground" onClick={() => sortBy("name")}>
                    Par <ArrowDownUp className="h-3 w-3" />
                  </button>
                </th>
                <th className="px-4 py-3 font-medium">
                  <button className="flex items-center gap-1 hover:text-foreground" onClick={() => sortBy("price")}>
                    Preço (USDT) <ArrowDownUp className="h-3 w-3" />
                  </button>
                </th>
                <th className="px-4 py-3 font-medium">
                  <button className="flex items-center gap-1 hover:text-foreground" onClick={() => sortBy("change")}>
                    Variação 24h <ArrowDownUp className="h-3 w-3" />
                  </button>
                </th>
                <th className="px-4 py-3 font-medium">Máx / Mín 24h</th>
                <th className="px-4 py-3 font-medium text-right">
                  <button className="inline-flex items-center gap-1 hover:text-foreground" onClick={() => sortBy("volume")}>
                    Volume 24h <ArrowDownUp className="h-3 w-3" />
                  </button>
                </th>
                <th className="px-4 py-3 text-center font-medium">Livro</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/40">
              {filtered.slice(0, limit).map((v) => (
                <tr key={v.symbol} className="transition-colors hover:bg-muted/30">
                  <td className="px-3 py-3 text-center">
                    <button
                      aria-label={`Favoritar ${v.base}`}
                      onClick={() => toggle(v.symbol)}
                      className="text-muted-foreground hover:text-primary"
                    >
                      <Star className={favorites.includes(v.symbol) ? "h-4 w-4 fill-primary text-primary" : "h-4 w-4"} />
                    </button>
                  </td>
                  <td className="px-4 py-3 font-semibold">
                    {v.base} <span className="font-normal text-muted-foreground text-xs">/ USDT</span>
                  </td>
                  <td className="px-4 py-3 font-mono-num font-medium">{price(v.lastPrice)}</td>
                  <td className={`px-4 py-3 font-mono-num font-semibold ${pnlColor(v.priceChangePercent)}`}>
                    {formatPct(v.priceChangePercent)}
                  </td>
                  <td className="px-4 py-3 font-mono-num text-xs text-muted-foreground">
                    <span>{price(v.highPrice)}</span> / <span>{price(v.lowPrice)}</span>
                  </td>
                  <td className="px-4 py-3 text-right font-mono-num font-medium">
                    {formatCompact(v.quoteVolume)}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setSelected(v.symbol)}>
                      Ver livro
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {!filtered.length && !isFetching && (
          <p className="py-12 text-center text-sm text-muted-foreground">Nenhum par encontrado.</p>
        )}

        {filtered.length > limit && (
          <div className="flex justify-center border-t border-border/60 p-4">
            <Button variant="outline" size="sm" onClick={() => setLimit((l) => l + 50)}>
              Carregar mais
            </Button>
          </div>
        )}
      </div>

      {/* Order Book Modal */}
      <Dialog open={!!selected} onOpenChange={(v) => !v && setSelected(null)}>
        <DialogContent className="max-w-md bg-card border-border/80">
          <DialogHeader>
            <DialogTitle className="font-bold">
              Livro de ordens · {selected?.replace("USDT", "/USDT")}
            </DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground">Ofertas reais Binance em tempo real</p>
          {book.error ? (
            <p className="text-loss text-sm">Livro indisponível</p>
          ) : !book.data ? (
            <p className="py-6 text-center text-sm text-muted-foreground">Carregando ofertas...</p>
          ) : (
            <div className="grid grid-cols-2 gap-4 pt-2">
              {((
                [
                  { key: "bids", title: "Compra", color: "text-profit" },
                  { key: "asks", title: "Venda", color: "text-loss" },
                ] as const
              ).map((side) => (
                <div key={side.key}>
                  <h3 className={`mb-2 font-semibold text-xs uppercase tracking-wider ${side.color}`}>{side.title}</h3>
                  <div className="mb-1.5 flex justify-between text-[11px] text-muted-foreground font-medium">
                    <span>Preço</span>
                    <span>Qtd</span>
                  </div>
                  <div className="space-y-1">
                    {book.data[side.key].slice(0, 10).map(([p, q]) => (
                      <div key={p} className="flex justify-between font-mono-num text-xs">
                        <span className={side.color}>{price(Number(p))}</span>
                        <span className="text-muted-foreground">{price(Number(q))}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
