import { createFileRoute, Link } from "@tanstack/react-router";
import { Bot, TrendingUp, Shield, LineChart, ArrowRight, Coins } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "BotPilot — Bots de cripto para estudo" },
      {
        name: "description",
        content:
          "Plataforma de estudo inspirada em bots de trading: crie bots DCA, acompanhe o mercado e simule trades com dinheiro fictício.",
      },
      { property: "og:title", content: "BotPilot — Bots de cripto para estudo" },
      {
        property: "og:description",
        content:
          "Crie bots DCA, acompanhe preços ao vivo e simule trades com dinheiro fictício.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LandingPage,
});

const features = [
  {
    icon: Bot,
    title: "Bots DCA",
    description:
      "Configure ordens base, ordens de segurança e take profit — igual às plataformas profissionais.",
  },
  {
    icon: LineChart,
    title: "Mercado ao vivo",
    description:
      "Preços reais de criptomoedas atualizados, com gráficos e variação de 24h.",
  },
  {
    icon: Shield,
    title: "Paper trading",
    description:
      "Simule trades com US$ 10.000 fictícios. Aprenda sem arriscar um centavo.",
  },
  {
    icon: TrendingUp,
    title: "Painel de desempenho",
    description:
      "Acompanhe lucro, deals abertos e a evolução do seu portfólio simulado.",
  },
];

function LandingPage() {
  return (
    <div className="min-h-screen bg-background bg-grid">
      <div className="bg-hero-radial">
        <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
              <Bot className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-bold tracking-tight">BotPilot</span>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/auth"
              className="rounded-md px-4 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              Entrar
            </Link>
            <Link
              to="/auth"
              search={{ mode: "signup" }}
              className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Criar conta
            </Link>
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-6">
          <section className="py-20 text-center md:py-28">
            <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-medium text-primary">
              <Coins className="h-3.5 w-3.5" />
              Projeto de estudo — 100% simulado
            </div>
            <h1 className="mx-auto max-w-3xl text-4xl font-bold leading-tight tracking-tight md:text-6xl">
              Aprenda trading automatizado{" "}
              <span className="text-primary text-glow">sem risco</span>
            </h1>
            <p className="mx-auto mt-6 max-w-xl text-base text-muted-foreground md:text-lg">
              Uma recriação para estudos das plataformas de bots de cripto: crie
              bots DCA, acompanhe o mercado em tempo real e simule operações com
              dinheiro fictício.
            </p>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
              <Link
                to="/auth"
                search={{ mode: "signup" }}
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:bg-primary/90 card-glow"
              >
                Começar a simular
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/auth"
                className="rounded-lg border border-border bg-card px-6 py-3 text-sm font-medium transition-colors hover:bg-accent"
              >
                Já tenho conta
              </Link>
            </div>
          </section>

          <section className="grid gap-4 pb-24 md:grid-cols-2 lg:grid-cols-4">
            {features.map((f) => (
              <div
                key={f.title}
                className="rounded-xl border border-border bg-card p-6 transition-colors hover:border-primary/40"
              >
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15">
                  <f.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {f.description}
                </p>
              </div>
            ))}
          </section>
        </main>
      </div>

      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground">
        BotPilot é um projeto educacional. Não é afiliado a nenhuma plataforma
        de trading. Nada aqui é recomendação de investimento.
      </footer>
    </div>
  );
}
