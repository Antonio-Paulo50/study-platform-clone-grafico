import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, X } from "lucide-react";
import { StartConditionFields } from "./indicator-fields";
import { CascadingPairSelector } from "./cascading-pair-selector";
import { DEFAULT_INDICATORS, DEFAULT_TIMEFRAME, entryTimeframe, indicatorConfigsSchema, indicatorConfigSchema, timeframeSchema, type IndicatorConfig, type IndicatorEntry, type Timeframe } from "@/lib/indicators";

/** `timeframe` é o tempo do primeiro indicador (mantido na coluna `bots.timeframe` por compatibilidade). */
export type EntryState = { mode: "immediate" | "indicator"; configs: IndicatorEntry[]; timeframe: Timeframe };
export function initialEntry(mode?: string | null, configs?: unknown, legacy?: unknown, timeframe?: unknown): EntryState {
  const list = indicatorConfigsSchema.safeParse(configs), single = indicatorConfigSchema.safeParse(legacy), interval = timeframeSchema.safeParse(timeframe);
  const botTimeframe: Timeframe = interval.success ? interval.data : DEFAULT_TIMEFRAME;
  const raw: IndicatorEntry[] = list.success ? (list.data as IndicatorEntry[]) : [single.success ? single.data : DEFAULT_INDICATORS.rsi];
  // Dados legados (sem tempo por indicador) herdam o tempo do bot.
  const entries = raw.map((config) => ({ ...config, timeframe: entryTimeframe(config, botTimeframe) }));
  return { mode: mode === "indicator" ? "indicator" : "immediate", configs: entries, timeframe: entries[0]?.timeframe ?? botTimeframe };
}
export function BotEntryFields({ value, onChange, prefix }: { value: EntryState; onChange: (value: EntryState) => void; prefix: string }) {
  return (
    <div className="space-y-4">
      <Tabs value={value.mode} onValueChange={mode => onChange({ ...value, mode: mode === "indicator" ? "indicator" : "immediate" })}>
        <TabsList className="w-full">
          <TabsTrigger className="flex-1" value="immediate">Imediato</TabsTrigger>
          <TabsTrigger className="flex-1" value="indicator">Indicadores</TabsTrigger>
        </TabsList>
      </Tabs>
      {value.mode === "indicator" && (
        <>
          <div className="text-sm font-medium">Condições de entrada · todas devem ser atendidas</div>
          {value.configs.map((config, index) => (
            <div key={index} className="space-y-2 border-b border-border pb-4">
              <div className="flex items-center justify-between">
                <Label>Indicador {index + 1}</Label>
                {value.configs.length > 1 && (
                  <Button
                    variant="ghost"
                    type="button"
                    size="icon"
                    aria-label={`Remover indicador ${index + 1}`}
                    onClick={() => { const rest = value.configs.filter((_, i) => i !== index); onChange({ ...value, configs: rest, timeframe: entryTimeframe(rest[0], value.timeframe) }); }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
              <StartConditionFields
                idPrefix={`${prefix}-${index}`}
                hideMode
                value={{ mode: "indicator", config: { ...config, timeframe: entryTimeframe(config, value.timeframe) } as IndicatorConfig }}
                onChange={v => {
                  const nextConfig = v.config as IndicatorEntry;
                  const nextConfigs = value.configs.map((old, i) => i === index ? nextConfig : old);
                  onChange({ ...value, configs: nextConfigs, timeframe: entryTimeframe(nextConfigs[0], value.timeframe) });
                }}
              />
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            disabled={value.configs.length >= 3}
            onClick={() => onChange({ ...value, configs: [...value.configs, { ...DEFAULT_INDICATORS.rsi, timeframe: entryTimeframe(value.configs.at(-1), value.timeframe) }] })}
          >
            <Plus className="mr-2 h-4 w-4" />Adicionar indicador ({value.configs.length}/3)
          </Button>
        </>
      )}
    </div>
  );
}
export function PairFields({ pairs, options, onChange, disabled = false }: { pairs: string[]; options: string[]; onChange: (pairs: string[]) => void; disabled?: boolean }) {
  return (
    <CascadingPairSelector
      pairs={pairs}
      options={options}
      onChange={onChange}
      disabled={disabled}
    />
  );
}
