import { useState, useMemo } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Plus, X, CheckSquare, Square } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";

export function CascadingPairSelector({
  pairs,
  options,
  onChange,
  disabled = false,
}: {
  pairs: string[];
  options: string[];
  onChange: (pairs: string[]) => void;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [quoteTab, setQuoteTab] = useState<"USDT" | "BTC" | "ETH">("USDT");

  const searchClean = search.toUpperCase().replace(/[^A-Z0-9]/g, "");

  // Filter by quote asset tab and search text
  const tabOptions = useMemo(() => {
    return options.filter((p) => p.endsWith(`/${quoteTab}`));
  }, [options, quoteTab]);

  const displayOptions = tabOptions.length > 0 ? tabOptions : options;

  const filteredOptions = useMemo(() => {
    if (!searchClean) return displayOptions;
    return displayOptions.filter((p) => p.replace("/", "").includes(searchClean));
  }, [displayOptions, searchClean]);

  const isAllSelected = displayOptions.length > 0 && displayOptions.every((p) => pairs.includes(p));

  const togglePair = (pair: string, checked: boolean) => {
    if (disabled) return;
    if (checked) {
      if (!pairs.includes(pair)) onChange([...pairs, pair]);
    } else {
      if (pairs.length <= 1) return;
      onChange(pairs.filter((p) => p !== pair));
    }
  };

  const removePair = (pair: string) => {
    if (disabled || pairs.length <= 1) return;
    onChange(pairs.filter((p) => p !== pair));
  };

  const selectAllUsdt = () => {
    if (disabled || displayOptions.length === 0) return;
    const merged = Array.from(new Set([...pairs, ...displayOptions]));
    onChange(merged);
  };

  const deselectAll = () => {
    if (disabled) return;
    const first = options[0];
    if (first) onChange([first]);
  };

  const formatClean = (pair: string) => pair.replace("/", "");

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-normal text-muted-foreground">Pairs</Label>
        <span className="text-xs text-muted-foreground/70 font-mono-num">
          {pairs.length} / {options.length}
        </span>
      </div>

            {/* 3Commas: chips com remoção individual e botão + Add pair fixo abaixo do primeiro par */}
      <div className="space-y-2">
        <div className="flex flex-wrap items-center gap-1.5">
          {pairs.map((pair) => (
            <div
              key={pair}
              className="inline-flex items-center gap-1 rounded bg-[#16202c] hover:bg-[#1c2938] text-[#c9d6e4] px-2.5 py-1 text-xs font-mono font-medium border border-[#233347] transition-colors select-none shadow-sm"
            >
              <span>{formatClean(pair)}</span>
              <button
                type="button"
                disabled={disabled || pairs.length <= 1}
                onClick={() => removePair(pair)}
                title={pairs.length <= 1 ? "Mínimo de 1 par necessário" : `Remover ${pair}`}
                aria-label={`Remover ${pair}`}
                className="ml-0.5 rounded p-0.5 text-[#6c7d93] hover:text-white hover:bg-[#24354a] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-start pt-0.5">
          <Popover open={open} onOpenChange={setOpen}>
            <PopoverTrigger asChild>
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={disabled}
                aria-label="Adicionar pares de moedas"
                className="h-7 gap-1.5 border border-[#2c3d52] bg-[#1e2c3d] px-2.5 text-xs font-medium text-[#c9d6e4] hover:bg-[#25374d] hover:text-white hover:border-[#384f6a] focus-visible:ring-1 focus-visible:ring-[#00c9a7] rounded transition-colors shadow-sm"
              >
                <Plus className="h-3.5 w-3.5 text-[#8fa2b8]" />
                <span>Add pair</span>
              </Button>
            </PopoverTrigger>
            <PopoverContent
              className="w-72 p-2.5 bg-[#0e1622] border-[#1e2d40] shadow-2xl rounded-md text-slate-200 z-50"
              align="start"
              sideOffset={4}
            >
              {/* Quote asset tabs USDT / BTC / ETH */}
              <div className="flex items-center gap-1 mb-2 border-b border-[#1d2b3c] pb-1.5">
                {(("USDT,BTC,ETH").split(",") as Array<"USDT" | "BTC" | "ETH">).map((tab) => (
                  <button
                    key={tab}
                    type="button"
                    onClick={() => setQuoteTab(tab)}
                    className={`px-2 py-0.5 text-[11px] font-semibold rounded transition-colors ${
                      quoteTab === tab
                        ? "bg-[#00c9a7] text-[#0a1118]"
                        : "text-[#73879c] hover:text-white hover:bg-[#16202c]"
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              {/* 3Commas Search Input */}
              <div className="relative mb-1.5">
                <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[#556980]" />
                <Input
                  className="h-8 pl-8 text-xs bg-[#141e2b] border-[#23354a] text-slate-100 placeholder:text-[#556980] focus-visible:ring-1 focus-visible:ring-[#00c9a7] focus-visible:border-[#00c9a7] rounded"
                  placeholder="Search pair..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  autoFocus
                />
              </div>

              {/* Quick action bar */}
              <div className="flex items-center justify-between px-1 py-1 mb-1 border-b border-[#1d2b3c] text-[11px]">
                <button
                  type="button"
                  onClick={selectAllUsdt}
                  disabled={disabled || isAllSelected || displayOptions.length === 0}
                  className="text-[#00c9a7] hover:underline font-medium disabled:opacity-40 disabled:no-underline"
                >
                  Select all ({displayOptions.length})
                </button>
                <button
                  type="button"
                  onClick={deselectAll}
                  disabled={disabled || pairs.length <= 1}
                  className="text-[#75889e] hover:text-white disabled:opacity-40 transition-colors"
                >
                  Reset (1)
                </button>
              </div>

            {/* 3Commas Checkbox List */}
            <ScrollArea className="h-60 pr-1">
              <div className="space-y-0.5">
                {filteredOptions.map((pair) => {
                  const isChecked = pairs.includes(pair);
                  const isOnly = isChecked && pairs.length === 1;
                  return (
                    <label
                      key={pair}
                      className="flex items-center gap-2.5 px-2 py-1.5 rounded cursor-pointer text-xs font-mono select-none hover:bg-[#1a2433] transition-colors text-slate-200"
                    >
                      <Checkbox
                        checked={isChecked}
                        disabled={disabled || isOnly}
                        onCheckedChange={(checked) => togglePair(pair, !!checked)}
                        className="h-4 w-4 rounded-[3px] border-[#384c63] data-[state=checked]:bg-[#00c9a7] data-[state=checked]:border-[#00c9a7] data-[state=checked]:text-[#0b131e] focus-visible:ring-0"
                      />
                      <span className={isChecked ? "text-[#e8f2fc] font-semibold" : "text-[#8da0b4]"}>
                        {formatClean(pair)}
                      </span>
                    </label>
                  );
                })}
                {filteredOptions.length === 0 && (
                  <p className="py-4 text-center text-xs text-muted-foreground">
                    No pairs found
                  </p>
                )}
              </div>
            </ScrollArea>
          </PopoverContent>
        </Popover>
      </div>
      </div>
    </div>
  );
}
