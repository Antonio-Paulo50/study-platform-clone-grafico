import { useState, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2, Pencil } from "lucide-react";
import { toast } from "sonner";
import { SUPPORTED_PAIRS, updateBot } from "@/lib/bots.functions";
import { getSpotMarkets } from "@/lib/market.functions";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { BotEntryFields, initialEntry } from "@/components/bot-entry-fields";
import { CascadingPairSelector } from "@/components/cascading-pair-selector";
import { BOT_LIMITS } from "@/lib/bot-limits";
import { createBotSchema } from "@/lib/bots.functions";

type BotRow = {
  id: string; name: string; pair: string; base_order_size: number; safety_order_size: number;
  max_safety_orders: number; price_deviation_pct: number; take_profit_pct: number; stop_loss_pct: number | null;
  start_condition?: string | null; indicator_config?: unknown; pairs?: string[]; timeframe?: string; indicator_configs?: unknown;
};

export function EditBotDialog({ bot, hasOpenDeal }: { bot: BotRow; hasOpenDeal: boolean }) {
  const queryClient = useQueryClient();
  const updateFn = useServerFn(updateBot);
  const fetchMarketsFn = useServerFn(getSpotMarkets);
  const { data: spotMarkets = [] } = useQuery({
    queryKey: ["spot-markets-pair-options"],
    queryFn: () => fetchMarketsFn(),
    staleTime: 60000,
  });
  const pairOptions = spotMarkets.length
    ? Array.from(new Set([...spotMarkets.map((m) => `${m.base}/USDT`), ...(bot.pairs?.length ? bot.pairs : [bot.pair])]))
    : SUPPORTED_PAIRS;
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [f, setF] = useState(() => init(bot));
  const [pairs, setPairs] = useState(bot.pairs?.length ? bot.pairs : [bot.pair]);
  const [start, setStart] = useState(() => initialEntry(bot.start_condition, bot.indicator_configs, bot.indicator_config, bot.timeframe));
  const set = (key: keyof ReturnType<typeof init>) => (value: string) => setF((s) => ({ ...s, [key]: value }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await updateFn({ data: {
        botId: bot.id, ...createBotSchema.parse({ name: f.name.trim(), pair: pairs[0], pairs, timeframe: start.timeframe,
        baseOrderSize: Number(f.base), safetyOrderSize: Number(f.safety), maxSafetyOrders: Number(f.count),
        priceDeviationPct: Number(f.deviation), takeProfitPct: Number(f.profit),
        ...(f.useStop ? { stopLossPct: Number(f.stop) } : {}),
        startCondition: start.mode,
        ...(start.mode === "indicator" ? { indicatorConfigs: start.configs } : {}),
      }) } });
      await queryClient.invalidateQueries({ queryKey: ["bot-detail", bot.id] });
      await queryClient.invalidateQueries({ queryKey: ["bots"] });
      toast.success("Bot atualizado");
      setOpen(false);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível salvar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (v) { setF(init(bot)); setPairs(bot.pairs?.length ? bot.pairs : [bot.pair]); setStart(initialEntry(bot.start_condition, bot.indicator_configs, bot.indicator_config, bot.timeframe)); } }}>
      <DialogTrigger asChild><Button variant="outline"><Pencil className="mr-2 h-4 w-4" />Editar</Button></DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar bot</DialogTitle>
          <DialogDescription>O histórico de deals é mantido. As mudanças valem para as próximas simulações.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2 sm:col-span-2"><Label htmlFor="e-name">Nome</Label><Input id="e-name" value={f.name} onChange={(e) => set("name")(e.target.value)} maxLength={60} required /></div>
          <div className="space-y-2 sm:col-span-2">
            <CascadingPairSelector pairs={pairs} options={pairOptions} onChange={setPairs} disabled={hasOpenDeal} />
            {hasOpenDeal && <p className="text-xs text-muted-foreground">Os pares não podem mudar enquanto houver operação aberta.</p>}
          </div>
          <div className="space-y-2 sm:col-span-2"><Label>Condição de início</Label><BotEntryFields prefix="edit-start" value={start} onChange={setStart} /></div>
          <Num id="e-base" label="Ordem base (USDT)" value={f.base} onChange={set("base")} min={String(BOT_LIMITS.orderSize.min)} max={String(BOT_LIMITS.orderSize.max)} />
          <Num id="e-safety" label="Ordem de segurança (USDT)" value={f.safety} onChange={set("safety")} min={String(BOT_LIMITS.orderSize.min)} max={String(BOT_LIMITS.orderSize.max)} />
          <Num id="e-count" label="Máx. ordens de segurança" value={f.count} onChange={set("count")} min={String(BOT_LIMITS.maxSafetyOrders.min)} max={String(BOT_LIMITS.maxSafetyOrders.max)} step="1" />
          <Num id="e-dev" label="Desvio entre ordens (%)" value={f.deviation} onChange={set("deviation")} min={String(BOT_LIMITS.priceDeviationPct.min)} max={String(BOT_LIMITS.priceDeviationPct.max)} />
          <Num id="e-tp" label="Take profit (%)" value={f.profit} onChange={set("profit")} min={String(BOT_LIMITS.takeProfitPct.min)} max={String(BOT_LIMITS.takeProfitPct.max)} />
          <div className="space-y-2">
            <div className="flex h-5 items-center justify-between"><Label htmlFor="e-use-stop">Stop loss (%)</Label><Switch id="e-use-stop" checked={f.useStop} onCheckedChange={(v) => setF((s) => ({ ...s, useStop: v }))} /></div>
            <Input aria-label="Stop loss em porcentagem" type="number" value={f.stop} onChange={(e) => set("stop")(e.target.value)} min={String(BOT_LIMITS.stopLossPct.min)} max={String(BOT_LIMITS.stopLossPct.max)} step="0.1" disabled={!f.useStop} required={f.useStop} />
          </div>
          <Button type="submit" className="sm:col-span-2" disabled={saving || !f.name.trim()}>{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Salvar alterações</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function init(bot: BotRow) {
  return {
    name: bot.name, pair: bot.pair, base: String(bot.base_order_size), safety: String(bot.safety_order_size),
    count: String(bot.max_safety_orders), deviation: String(bot.price_deviation_pct), profit: String(bot.take_profit_pct),
    useStop: bot.stop_loss_pct != null, stop: String(bot.stop_loss_pct ?? 10),
  };
}

function Num({ id, label, value, onChange, min, max, step = "0.1" }: { id: string; label: string; value: string; onChange: (v: string) => void; min: string; max: string; step?: string }) {
  return <div className="space-y-2"><Label htmlFor={id}>{label}</Label><Input id={id} type="number" value={value} onChange={(e) => onChange(e.target.value)} min={min} max={max} step={step} required /></div>;
}
