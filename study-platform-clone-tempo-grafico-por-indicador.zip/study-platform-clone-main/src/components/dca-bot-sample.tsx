import { useState, type ReactNode } from "react";
import { Bot, Check, FlaskConical, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { SUPPORTED_PAIRS } from "@/lib/bots.functions";
import { StartConditionFields, initialStart } from "@/components/indicator-fields";
import { describeIndicator } from "@/lib/indicators";
import { formatUsd } from "@/lib/format";

export function DcaBotSample() {
  const [name, setName] = useState("Meu bot DCA");
  const [pair, setPair] = useState("BTC/USDT");
  const [direction, setDirection] = useState("long");
  const [advanced, setAdvanced] = useState(false);
  const [entry, setEntry] = useState("immediate");
  const [start, setStart] = useState(initialStart("indicator"));
  const [amount, setAmount] = useState("20");
  const [mode, setMode] = useState("position");
  const [method, setMethod] = useState("coin");
  const [orders, setOrders] = useState("20");
  const [deviation, setDeviation] = useState("0.8");
  const [sizeMultiplier, setSizeMultiplier] = useState("1");
  const [stepMultiplier, setStepMultiplier] = useState("1.2");
  const [profit, setProfit] = useState("0.8");
  const [profitType, setProfitType] = useState("average");
  const [stop, setStop] = useState(false);
  const [stopPct, setStopPct] = useState("10");
  const [breakeven, setBreakeven] = useState(false);
  const [trailing, setTrailing] = useState(false);
  const [trailingPct, setTrailingPct] = useState("0.2");
  const [review, setReview] = useState(false);
  const count = Math.min(100, Math.max(0, Math.floor(Number(orders) || 0)));
  const base = Math.max(0, Number(amount) || 0);
  const multiplier = Math.max(1, Math.min(5, Number(sizeMultiplier) || 1));
  const allocation = base + Array.from({ length: count }, (_, index) => base * multiplier ** index).reduce((sum, value) => sum + value, 0);
  const directionLabel = direction === "long" ? "Long" : direction === "short" ? "Short" : "Ambos";
  const entryLabel = entry === "immediate" ? "Imediato" : describeIndicator(start.config);

  return (
    <div className="grid items-start gap-8 lg:grid-cols-[minmax(0,1fr)_300px]">
      <div className="min-w-0">
        <Section title="Geral" number="01">
          <Field label="Nome do bot" id="sample-name"><Input id="sample-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} /></Field>
          <Field label="Conta de negociação" id="sample-account"><Input id="sample-account" value="BotPilot · Conta demonstrativa" readOnly /></Field>
          <Field label="Par de negociação" id="sample-pair"><Choice id="sample-pair" value={pair} onChange={setPair} options={SUPPORTED_PAIRS.map((value) => [value, value])} /></Field>
          <Field label="Direção"><Segments label="Direção" value={direction} onChange={setDirection} options={[["long", "Long"], ["short", "Short"], ["both", "Ambos"]]} /></Field>
        </Section>

        <Section title="Entrada" number="02">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3"><Label>Condição de início</Label><div className="flex items-center gap-2"><Switch id="sample-advanced" checked={advanced} onCheckedChange={(value) => { setAdvanced(value); if (!value) setEntry("immediate"); }} /><Label htmlFor="sample-advanced" className="text-xs text-muted-foreground">Configurações avançadas</Label></div></div>
            <Segments label="Condição de início" value={entry} onChange={(value) => { setEntry(value); if (value === "indicator") setAdvanced(true); }} options={[["immediate", "Imediato"], ["indicator", "Indicador"]]} />
          </div>
          {advanced && entry === "indicator" && <StartConditionFields idPrefix="sample-start" value={start} onChange={v => { setStart(v); setEntry(v.mode); }} />}
          <div className="space-y-3"><NumberField label="Valor por operação (USDT)" id="sample-amount" value={amount} onChange={setAmount} min="1" max="10000" /><div className="grid grid-cols-5 gap-2">{[5, 10, 25, 50, 100].map((pct) => <Button key={pct} type="button" variant="secondary" size="sm" className="px-0" onClick={() => setAmount(String(10000 * pct / 100))}>{pct}%</Button>)}</div><p className="text-xs text-muted-foreground">Referência da amostra: 10.000 USDT virtuais</p></div>
          <Field label="Modo DCA"><Segments label="Modo DCA" value={mode} onChange={setMode} options={[["order", "Média de ordens"], ["position", "Média de posição"]]} /></Field>
          <Field label="Método de média"><Segments label="Método de média" value={method} onChange={setMethod} options={[["coin", "Quantidade fixa"], ["value", "Valor fixo"]]} /></Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <NumberField label="Máximo de ordens DCA" id="sample-orders" value={orders} onChange={setOrders} min="0" max="100" step="1" />
            <NumberField label="Desvio de preço (%)" id="sample-deviation" value={deviation} onChange={setDeviation} min="0.1" max="50" />
            <NumberField label="Multiplicador de valor" id="sample-size" value={sizeMultiplier} onChange={setSizeMultiplier} min="1" max="5" />
            <NumberField label="Multiplicador de desvio" id="sample-step" value={stepMultiplier} onChange={setStepMultiplier} min="1" max="5" />
          </div>
        </Section>

        <Section title="Saída" number="03">
          <div className="grid gap-4 sm:grid-cols-2"><NumberField label="Alvo de take profit (%)" id="sample-profit" value={profit} onChange={setProfit} min="0.1" max="50" /><Field label="Tipo de take profit" id="sample-profit-type"><Choice id="sample-profit-type" value={profitType} onChange={setProfitType} options={[["average", "Sobre o preço médio"], ["base", "Sobre a ordem inicial"]]} /></Field></div>
          <Toggle id="sample-stop" label="Stop loss" value={stop} onChange={setStop} />
          {stop && <NumberField label="Stop loss (%)" id="sample-stop-pct" value={stopPct} onChange={setStopPct} min="0.1" max="80" />}
          <Toggle id="sample-break" label="Mover stop loss para breakeven" value={breakeven} onChange={setBreakeven} />
          <Toggle id="sample-trailing" label="Trailing stop" value={trailing} onChange={setTrailing} />
          {trailing && <NumberField label="Distância do trailing (%)" id="sample-trailing-pct" value={trailingPct} onChange={setTrailingPct} min="0.1" max="50" />}
        </Section>
      </div>

      <aside className="space-y-6 border-t border-border pt-6 lg:sticky lg:top-8 lg:border-t-0 lg:border-l lg:pl-6 lg:pt-0">
        <div className="flex items-center gap-2 text-primary"><FlaskConical className="h-4 w-4" /><span className="text-xs font-medium uppercase">Amostra interativa</span></div>
        <div><div className="mb-3 flex items-center gap-2"><Bot className="h-5 w-5 text-primary" /><h2 className="font-semibold">Resumo do bot</h2></div><p className="break-words text-sm text-muted-foreground">{name || "Sem nome"}</p></div>
        <div className="space-y-4"><Row label="Par" value={pair} /><Row label="Direção" value={directionLabel} /><Row label="Entrada" value={entryLabel} /><Row label="Ordens DCA" value={String(count)} /><Row label="Take profit" value={`${Number(profit || 0)}%`} /></div>
        <div className="border-y border-border py-5"><p className="mb-2 text-xs text-muted-foreground">Capital estimado · valor fixo</p><p className="break-all font-mono text-2xl font-semibold">{formatUsd(allocation)}</p><p className="mt-2 text-xs text-muted-foreground">Ordem inicial + ordens DCA com multiplicador</p></div>
        <div className="flex gap-2 text-xs leading-relaxed text-muted-foreground"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" /><p>Prévia sem execução. Estas opções não são salvas e nenhuma ordem será enviada.</p></div>
        <Button type="button" className="w-full" disabled={!name.trim()} onClick={() => setReview(true)}><Check className="h-4 w-4" />Revisar amostra</Button>
      </aside>

      <Dialog open={review} onOpenChange={setReview}><DialogContent><DialogHeader><DialogTitle>{name}</DialogTitle><DialogDescription>Amostra de configuração · sem salvar ou executar operações.</DialogDescription></DialogHeader><div className="space-y-4 py-3"><Row label="Par / direção" value={`${pair} · ${directionLabel}`} /><Row label="Entrada" value={entryLabel} /><Row label="Modo DCA" value={mode === "position" ? "Média de posição" : "Média de ordens"} /><Row label="Método" value={method === "coin" ? "Quantidade fixa" : "Valor fixo"} /><Row label="Ordens / desvio" value={`${count} / ${deviation}%`} /><Row label="Multiplicadores · valor / desvio" value={`${sizeMultiplier} / ${stepMultiplier}`} /><Row label="Take profit" value={`${profit}% · ${profitType === "average" ? "Preço médio" : "Ordem inicial"}`} /><Row label="Stop loss" value={stop ? `${stopPct}%` : "Desativado"} /><Row label="Breakeven" value={breakeven ? "Ativado" : "Desativado"} /><Row label="Trailing stop" value={trailing ? `${trailingPct}%` : "Desativado"} /><Row label="Capital estimado · valor fixo" value={formatUsd(allocation)} /></div><Button onClick={() => setReview(false)}>Continuar ajustando</Button></DialogContent></Dialog>
    </div>
  );
}

function Section({ title, number, children }: { title: string; number: string; children: ReactNode }) {
  return <section className="mb-6 space-y-5 border-b border-border pb-6"><div className="flex items-center gap-3"><span className="font-mono text-xs text-primary">{number}</span><h2 className="font-semibold">{title}</h2></div>{children}</section>;
}
function Field({ label, id, children }: { label: string; id?: string; children: ReactNode }) {
  return <div className="min-w-0 space-y-2"><Label htmlFor={id}>{label}</Label>{children}</div>;
}
function NumberField({ label, id, value, onChange, min, max, step = "0.1" }: { label: string; id: string; value: string; onChange: (value: string) => void; min: string; max: string; step?: string }) {
  return <Field label={label} id={id}><Input id={id} type="number" min={min} max={max} step={step} value={value} onChange={(e) => onChange(e.target.value)} /></Field>;
}
function Choice({ id, value, onChange, options }: { id: string; value: string; onChange: (value: string) => void; options: Array<[string, string]> }) {
  return <Select value={value} onValueChange={onChange}><SelectTrigger id={id} className="w-full"><SelectValue /></SelectTrigger><SelectContent>{options.map(([key, label]) => <SelectItem key={key} value={key}>{label}</SelectItem>)}</SelectContent></Select>;
}
function Segments({ label, value, onChange, options }: { label: string; value: string; onChange: (value: string) => void; options: Array<[string, string]> }) {
  return <Tabs value={value} onValueChange={onChange}><TabsList aria-label={label} className="flex h-10 w-full">{options.map(([key, title]) => <TabsTrigger key={key} value={key} className="min-w-0 flex-1 px-2 text-xs sm:text-sm">{title}</TabsTrigger>)}</TabsList></Tabs>;
}
function Toggle({ id, label, value, onChange }: { id: string; label: string; value: boolean; onChange: (value: boolean) => void }) {
  return <div className="flex items-center gap-3"><Switch id={id} checked={value} onCheckedChange={onChange} /><Label htmlFor={id}>{label}</Label></div>;
}
function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex items-start justify-between gap-4 text-sm"><span className="text-muted-foreground">{label}</span><span className="min-w-0 break-words text-right font-medium">{value}</span></div>;
}