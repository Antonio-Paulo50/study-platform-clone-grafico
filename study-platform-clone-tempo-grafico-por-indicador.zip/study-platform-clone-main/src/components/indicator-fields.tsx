import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  CONDITION_LABELS, DEFAULT_INDICATORS, INDICATOR_NAMES, TIMEFRAMES, describeIndicator, entryTimeframe, indicatorConfigSchema,
  type IndicatorConfig, type IndicatorType, type Timeframe,
} from "@/lib/indicators";

export type StartState = { mode: "immediate" | "indicator"; config: IndicatorConfig };

export function initialStart(mode?: string | null, config?: unknown): StartState {
  const parsed = indicatorConfigSchema.safeParse(config);
  return { mode: mode === "indicator" ? "indicator" : "immediate", config: parsed.success ? parsed.data : DEFAULT_INDICATORS.rsi };
}

export function StartConditionFields({ value, onChange, idPrefix, hideMode = false }: { value: StartState; onChange: (v: StartState) => void; idPrefix: string; hideMode?: boolean }) {
  const c = value.config;
  const timeframe = entryTimeframe(c as { timeframe?: unknown });
  const patch = (p: Record<string, unknown>) => onChange({ ...value, config: { ...c, ...p } as IndicatorConfig });
  const num = (key: string, label: string, v: number, min: number, max: number, step = 1) => (
    <div className="space-y-2">
      <Label htmlFor={`${idPrefix}-${key}`}>{label}</Label>
      <Input id={`${idPrefix}-${key}`} type="number" value={Number.isFinite(v) ? v : ""} min={min} max={max} step={step} required
        onChange={(e) => patch({ [key]: e.target.value === "" ? NaN : Number(e.target.value) })} />
    </div>
  );
  const conditions: Record<IndicatorType, string[]> = {
    ultimate: ["cross_up", "cross_down", "above", "below"], cci: ["cross_up", "cross_down", "above", "below"], heikin_ashi: ["bullish", "bearish", "turn_bullish", "turn_bearish"],
    adx: ["cross_up", "cross_down", "above", "below"], mfi: ["cross_up", "cross_down", "above", "below"],
    ma: ["cross_up", "cross_down", "above", "below"], sar: ["cross_up", "cross_down", "above", "below"],
    bb_percent: ["cross_up", "cross_down", "above", "below"], stochastic: ["cross_up", "cross_down", "above", "below"],
    rsi: ["cross_up", "cross_down", "above", "below"],
    macd: ["cross_up", "cross_down"],
    bb: ["below_lower", "above_upper", "cross_up_lower"],
    price_change: ["drop", "rise"],
  };

  return (
    <div className="space-y-4">
      {!hideMode && <Tabs value={value.mode} onValueChange={(m) => onChange({ ...value, mode: m as StartState["mode"] })}>
        <TabsList aria-label="Condição de início" className="flex h-10 w-full">
          <TabsTrigger value="immediate" className="flex-1">Imediato</TabsTrigger>
          <TabsTrigger value="indicator" className="flex-1">Indicador</TabsTrigger>
        </TabsList>
      </Tabs>}
      {value.mode === "indicator" && (
        <div className="grid gap-4 rounded-lg border border-border p-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor={`${idPrefix}-type`}>Indicador</Label>
            <Select value={c.type} onValueChange={(t) => onChange({ ...value, config: { ...DEFAULT_INDICATORS[t as IndicatorType], timeframe } as IndicatorConfig })}>
              <SelectTrigger id={`${idPrefix}-type`}><SelectValue /></SelectTrigger>
              <SelectContent>{(Object.keys(INDICATOR_NAMES) as IndicatorType[]).filter(t => t !== "bb").map((t) => <SelectItem key={t} value={t}>{INDICATOR_NAMES[t]}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor={`${idPrefix}-cond`}>Condição</Label>
            <Select key={c.type} value={c.condition} onValueChange={(v) => { if (conditions[c.type].includes(v)) patch({ condition: v }); }}>
              <SelectTrigger id={`${idPrefix}-cond`}><SelectValue /></SelectTrigger>
              <SelectContent>{conditions[c.type].map((k) => <SelectItem key={k} value={k}>{CONDITION_LABELS[k]}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          {c.type === "ultimate" && <>{num("fast", "Período curto", c.fast, 2, 50)}{num("middle", "Período médio", c.middle, 3, 100)}{num("slow", "Período longo", c.slow, 4, 200)}{num("level", "Nível", c.level, 0, 100)}</>}
          {c.type === "cci" && <>{num("period", "Períodos", c.period, 2, 100)}{num("level", "Nível CCI", c.level, -500, 500)}</>}
          {c.type === "heikin_ashi" && num("count", "Candles consecutivos", c.count, 1, 10)}
          {(c.type === "adx" || c.type === "mfi") && <>{num("period", "Períodos", c.period, 2, 100)}{num("level", "Nível", c.level, 0, 100)}</>}
          {c.type === "ma" && <>
            <div className="space-y-2"><Label htmlFor={`${idPrefix}-method`}>Tipo de média</Label><Select value={c.method} onValueChange={method => patch({ method })}><SelectTrigger id={`${idPrefix}-method`}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="sma">SMA · Simples</SelectItem><SelectItem value="ema">EMA · Exponencial</SelectItem></SelectContent></Select></div>
            {num("fast", "Período rápido", c.fast, 2, 100)}{num("slow", "Período lento", c.slow, 3, 200)}
          </>}
          {c.type === "sar" && <>{num("step", "Passo de aceleração", c.step, 0.001, 0.1, 0.001)}{num("max", "Aceleração máxima", c.max, 0.01, 1, 0.01)}</>}
          {c.type === "bb_percent" && <>{num("period", "Períodos", c.period, 5, 100)}{num("stdDev", "Desvios padrão", c.stdDev, 0.5, 4, 0.1)}{num("level", "Nível BB% (0–100 = entre bandas)", c.level, -200, 300, 0.1)}</>}
          {c.type === "stochastic" && <>
            {num("period", "Período %K", c.period, 2, 100)}{num("smoothing", "Suavização %K", c.smoothing, 1, 20)}{num("signal", "Período %D", c.signal, 1, 20)}
            <div className="space-y-2"><Label htmlFor={`${idPrefix}-target`}>Comparar %K com</Label><Select value={c.target} onValueChange={target => patch({ target })}><SelectTrigger id={`${idPrefix}-target`}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="level">Nível</SelectItem><SelectItem value="signal">Linha %D</SelectItem></SelectContent></Select></div>
            {c.target === "level" && num("level", "Nível", c.level, 0, 100)}
          </>}
          {c.type === "rsi" && <>{num("period", "Períodos", c.period, 2, 50)}{num("level", "Nível", c.level, 1, 99)}</>}
          {c.type === "macd" && <>{num("fast", "Período rápido", c.fast, 2, 50)}{num("slow", "Período lento", c.slow, 3, 100)}{num("signal", "Linha de sinal", c.signal, 2, 50)}</>}
          {c.type === "bb" && <>{num("period", "Períodos", c.period, 5, 50)}{num("stdDev", "Desvios padrão", c.stdDev, 0.5, 4, 0.1)}</>}
          {c.type === "price_change" && <>{num("pct", "Variação (%)", c.pct, 0.1, 50, 0.1)}{num("hours", "Janela (horas)", c.hours, 1, 72)}</>}
          <div className="flex items-center justify-between gap-4 sm:col-span-2">
            <Label htmlFor={`${idPrefix}-timeframe`}>Tempo Gráfico</Label>
            <Select value={timeframe} onValueChange={(tf) => patch({ timeframe: tf as Timeframe })}>
              <SelectTrigger id={`${idPrefix}-timeframe`} className="w-40" aria-label="Tempo gráfico do indicador"><SelectValue /></SelectTrigger>
              <SelectContent>{(Object.keys(TIMEFRAMES) as Timeframe[]).map((tf) => <SelectItem key={tf} value={tf}>{TIMEFRAMES[tf]}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <p className="text-xs text-muted-foreground sm:col-span-2">{describeIndicator(c)}</p>
        </div>
      )}
    </div>
  );
}
