/**
 * Fonte única dos limites de configuração de um bot.
 *
 * Usada por: schema Zod (`createBotSchema`), formulários de criar/editar bot e
 * pelas CHECKs do banco (drizzle/migrations/0005_integrity_constraints.sql).
 * Se alterar um valor aqui, altere a migração correspondente — o teste
 * `src/test/bot-limits.test.ts` falha quando os dois divergem.
 */
export const BOT_LIMITS = {
  /** Tamanho das ordens base e de segurança, em USDT. No banco: > 0. */
  orderSize: { min: 1, max: 100000 },
  maxSafetyOrders: { min: 0, max: 10 },
  priceDeviationPct: { min: 0.1, max: 20 },
  takeProfitPct: { min: 0.1, max: 50 },
  stopLossPct: { min: 0.5, max: 80 },
  pairsPerBot: { min: 1, max: 100 },
} as const;

/** Converte um intervalo em atributos `min`/`max` (strings) de <input type="number">. */
export function inputBounds(limit: { readonly min: number; readonly max: number }) {
  return { min: String(limit.min), max: String(limit.max) };
}
