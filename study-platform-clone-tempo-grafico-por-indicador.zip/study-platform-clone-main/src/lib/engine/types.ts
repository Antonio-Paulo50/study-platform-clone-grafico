export type BotStatus = "active" | "paused" | "stopped";

/** Configuração do bot que o motor precisa; independe do formato das linhas do banco. */
export interface BotConfig {
  id: string;
  status: BotStatus;
  baseOrderSize: number;
  safetyOrderSize: number;
  maxSafetyOrders: number;
  /** Desvio (%) da primeira ordem de segurança. */
  priceDeviationPct: number;
  /** Multiplica o desvio a cada nível (padrão 1 = desvio constante). */
  safetyStepScale?: number;
  /** Multiplica o volume a cada nível (padrão 1 = volume constante). */
  safetyVolumeScale?: number;
  takeProfitPct: number;
  stopLossPct: number | null;
}

export interface DealState {
  id: string;
  pair: string;
  /** Preço da ordem base: referência da escada de ordens de segurança. */
  basePrice: number;
  /** Preço médio atual (soma investida / soma da quantidade). */
  avgPrice: number;
  invested: number;
  quantity: number;
  safetyOrdersUsed: number;
}

export interface Quote {
  bid: number;
  ask: number;
}

export interface OpenAction {
  type: "open";
  botId: string;
  pair: string;
  price: number;
  quantity: number;
  quoteAmount: number;
  basePrice: number;
}

export interface SafetyAction {
  type: "safety";
  dealId: string;
  level: number;
  price: number;
  quantity: number;
  quoteAmount: number;
}

export interface CloseAction {
  type: "close";
  dealId: string;
  reason: "take_profit" | "stop_loss";
  price: number;
  quantity: number;
  /** Valor recebido na venda, em USDT. */
  quoteAmount: number;
}

export type EngineAction = OpenAction | SafetyAction | CloseAction;

export type SkipReason =
  | "bot_inactive"
  | "invalid_quote"
  | "insufficient_balance"
  | "waiting_signal";
