import { round8 } from "./math";
import type { BotConfig } from "./types";

type LadderBot = Pick<
  BotConfig,
  | "baseOrderSize"
  | "safetyOrderSize"
  | "maxSafetyOrders"
  | "priceDeviationPct"
  | "safetyStepScale"
  | "safetyVolumeScale"
>;

export interface LadderRow {
  level: number;
  /** Queda acumulada (%) a partir do preço da ordem base. */
  dropPct: number;
  triggerPrice: number;
  size: number;
  /** Capital total comprometido até este nível, incluindo a ordem base. */
  cumulativeCost: number;
}

function assertLevel(level: number): void {
  if (!Number.isInteger(level) || level < 1) {
    throw new RangeError("level deve ser inteiro >= 1");
  }
}

/**
 * Queda acumulada (%) até o nível `level`: dev × (1 + step + step² + … + step^(level-1)).
 * Com step = 1 vira `level × dev`. Exemplo oficial da 3Commas (dev 0,5 e step 2): 0,5 / 1,5 / 3,5.
 */
export function cumulativeDropPct(level: number, deviationPct: number, stepScale = 1): number {
  assertLevel(level);
  let drop = 0;
  let step = deviationPct;
  for (let i = 0; i < level; i++) {
    drop += step;
    step *= stepScale;
  }
  return drop;
}

/** Preço que dispara a ordem de segurança `level`, medido a partir da ordem base (mínimo 0). */
export function safetyTriggerPrice(
  basePrice: number,
  level: number,
  deviationPct: number,
  stepScale = 1,
): number {
  return Math.max(0, basePrice * (1 - cumulativeDropPct(level, deviationPct, stepScale) / 100));
}

/** Tamanho (USDT) da ordem de segurança `level`: size × volumeScale^(level-1). */
export function safetyOrderSize(size: number, level: number, volumeScale = 1): number {
  assertLevel(level);
  return round8(size * Math.pow(volumeScale, level - 1));
}

/** Capital máximo que uma operação pode consumir: ordem base + todas as ordens de segurança. */
export function maxDealCost(bot: LadderBot): number {
  let total = bot.baseOrderSize;
  for (let level = 1; level <= bot.maxSafetyOrders; level++) {
    total += safetyOrderSize(bot.safetyOrderSize, level, bot.safetyVolumeScale);
  }
  return round8(total);
}

/** Tabela completa da escada (base para o equivalente ao "Bot Assistant" da 3Commas). */
export function buildLadder(bot: LadderBot, basePrice: number): LadderRow[] {
  const rows: LadderRow[] = [];
  let cumulativeCost = bot.baseOrderSize;
  for (let level = 1; level <= bot.maxSafetyOrders; level++) {
    const size = safetyOrderSize(bot.safetyOrderSize, level, bot.safetyVolumeScale);
    cumulativeCost = round8(cumulativeCost + size);
    rows.push({
      level,
      dropPct: cumulativeDropPct(level, bot.priceDeviationPct, bot.safetyStepScale),
      triggerPrice: safetyTriggerPrice(
        basePrice,
        level,
        bot.priceDeviationPct,
        bot.safetyStepScale,
      ),
      size,
      cumulativeCost,
    });
  }
  return rows;
}
