import { round8 } from "./math";
import { safetyOrderSize, safetyTriggerPrice } from "./ladder";
import type { BotConfig, CloseAction, DealState, EngineAction, Quote } from "./types";

/**
 * Decide o que fazer com uma operação aberta em um instante (modo "ponto no tempo").
 *
 * Ordem de prioridade: take profit, stop loss, ordem de segurança. No máximo uma ação por chamada.
 * O gatilho da ordem de segurança é medido a partir do preço da ORDEM BASE (não do preço médio).
 * `availableBalance` impede a compra de segurança quando não há saldo (padrão: sem limite).
 * Bot pausado ou parado não gera ação (comportamento atual; ver [CONFIRMAR] da Fase 5).
 */
export function evaluateDeal(
  bot: BotConfig,
  deal: DealState,
  quote: Quote,
  availableBalance = Number.POSITIVE_INFINITY,
): EngineAction[] {
  if (bot.status !== "active") return [];
  if (!(quote.bid > 0 && quote.ask > 0)) return [];

  const takeProfitPrice = deal.avgPrice * (1 + bot.takeProfitPct / 100);
  if (quote.bid >= takeProfitPrice) return [closeAction(deal, quote.bid, "take_profit")];

  if (bot.stopLossPct != null) {
    const stopLossPrice = deal.avgPrice * (1 - bot.stopLossPct / 100);
    if (quote.bid <= stopLossPrice) return [closeAction(deal, quote.bid, "stop_loss")];
  }

  if (deal.safetyOrdersUsed < bot.maxSafetyOrders) {
    const level = deal.safetyOrdersUsed + 1;
    const trigger = safetyTriggerPrice(
      deal.basePrice,
      level,
      bot.priceDeviationPct,
      bot.safetyStepScale,
    );
    const size = safetyOrderSize(bot.safetyOrderSize, level, bot.safetyVolumeScale);
    if (quote.ask <= trigger && availableBalance >= size) {
      return [
        {
          type: "safety",
          dealId: deal.id,
          level,
          price: quote.ask,
          quantity: round8(size / quote.ask),
          quoteAmount: size,
        },
      ];
    }
  }
  return [];
}

function closeAction(deal: DealState, price: number, reason: CloseAction["reason"]): CloseAction {
  return {
    type: "close",
    dealId: deal.id,
    reason,
    price,
    quantity: deal.quantity,
    quoteAmount: round8(deal.quantity * price),
  };
}
