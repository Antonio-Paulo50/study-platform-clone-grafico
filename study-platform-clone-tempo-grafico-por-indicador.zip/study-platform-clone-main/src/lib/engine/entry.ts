import { round8 } from "./math";
import type { BotConfig, OpenAction, Quote, SkipReason } from "./types";

/**
 * Verificações baratas ANTES de buscar candles/indicadores (evita I/O desnecessário).
 * Devolve o motivo de não abrir ou `null` se pode seguir para a avaliação do sinal.
 */
export function entryPrecheck(
  bot: Pick<BotConfig, "status" | "baseOrderSize">,
  quote: Quote,
  availableBalance: number,
): SkipReason | null {
  if (bot.status !== "active") return "bot_inactive";
  if (!(quote.bid > 0 && quote.ask > 0)) return "invalid_quote";
  if (availableBalance < bot.baseOrderSize) return "insufficient_balance";
  return null;
}

/** Monta a ação de abertura: compra a mercado ao ask; o preço vira o `basePrice` da operação. */
export function buildOpenAction(
  bot: Pick<BotConfig, "id" | "baseOrderSize">,
  pair: string,
  quote: Quote,
): OpenAction {
  return {
    type: "open",
    botId: bot.id,
    pair,
    price: quote.ask,
    quantity: round8(bot.baseOrderSize / quote.ask),
    quoteAmount: bot.baseOrderSize,
    basePrice: quote.ask,
  };
}

export type EntryDecision = { action: OpenAction } | { skipped: SkipReason };

/** Atalho que combina as duas etapas quando o sinal do indicador já está calculado. */
export function decideEntry(
  bot: BotConfig,
  pair: string,
  quote: Quote,
  availableBalance: number,
  signalOk: boolean,
): EntryDecision {
  const skipped = entryPrecheck(bot, quote, availableBalance);
  if (skipped) return { skipped };
  if (!signalOk) return { skipped: "waiting_signal" };
  return { action: buildOpenAction(bot, pair, quote) };
}
