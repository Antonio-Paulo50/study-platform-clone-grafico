/** Arredonda para 8 casas decimais (mesma precisão de NUMERIC(20,8) no banco). */
export function round8(value: number): number {
  return Math.round(value * 1e8) / 1e8;
}

/**
 * Arredonda PARA BAIXO ao múltiplo de `step` (filtros LOT_SIZE da exchange).
 * Um `step` inválido (<= 0) devolve o valor sem alteração.
 */
export function floorToStep(value: number, step: number): number {
  if (!(step > 0)) return value;
  // a folga de 1e-9 evita 0.3 / 0.1 = 2.9999999999999996 virar 2 passos
  return round8(Math.floor(value / step + 1e-9) * step);
}
