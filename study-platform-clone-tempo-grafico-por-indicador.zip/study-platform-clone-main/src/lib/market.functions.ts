import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export type MarketCoin = {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  price_change_percentage_24h: number | null;
  market_cap: number;
  total_volume: number;
  sparkline: number[];
};

type CoinGeckoMarket = {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  price_change_percentage_24h: number | null;
  market_cap: number;
  total_volume: number;
  sparkline_in_7d?: { price: number[] };
};

const COINGECKO = "https://api.coingecko.com/api/v3";

export const getMarkets = createServerFn({ method: "GET" }).handler(
  async (): Promise<MarketCoin[]> => {
    const res = await fetch(
      `${COINGECKO}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=20&page=1&sparkline=true&price_change_percentage=24h`,
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) throw new Error("Falha ao buscar preços do mercado");
    const data = (await res.json()) as CoinGeckoMarket[];
    return data.map((c) => ({
      id: c.id,
      symbol: c.symbol.toUpperCase(),
      name: c.name,
      image: c.image,
      current_price: c.current_price,
      price_change_percentage_24h: c.price_change_percentage_24h,
      market_cap: c.market_cap,
      total_volume: c.total_volume,
      sparkline: c.sparkline_in_7d?.price ?? [],
    }));
  },
);

export const getPriceHistory = createServerFn({ method: "GET" })
  .inputValidator((data) =>
    z.object({ coinId: z.string(), days: z.number().min(1).max(90).default(7) }).parse(data),
  )
  .handler(async ({ data }): Promise<{ time: number; price: number }[]> => {
    const res = await fetch(
      `${COINGECKO}/coins/${data.coinId}/market_chart?vs_currency=usd&days=${data.days}`,
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) throw new Error("Falha ao buscar histórico de preços");
    const json = (await res.json()) as { prices: [number, number][] };
    return json.prices.map(([time, price]) => ({ time, price }));
  });

export const getSpotMarkets = createServerFn({ method: "GET" }).handler(async () => {
  const res = await fetch("https://api.binance.com/api/v3/ticker/24hr", { signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error("Mercado temporariamente indisponível");
  const rows = z.array(z.object({ symbol: z.string(), lastPrice: z.coerce.number(), priceChangePercent: z.coerce.number(), highPrice: z.coerce.number(), lowPrice: z.coerce.number(), quoteVolume: z.coerce.number(), count: z.number() })).parse(await res.json());
  return rows.filter(v => v.symbol.endsWith("USDT") && v.lastPrice > 0 && v.count > 0).map(v => ({ ...v, base: v.symbol.slice(0, -4) })).sort((a,b) => b.quoteVolume - a.quoteVolume);
});
export const getOrderBook = createServerFn({ method: "GET" }).inputValidator(data => z.object({ symbol: z.string().regex(/^[A-Z0-9]{2,20}USDT$/) }).parse(data)).handler(async ({ data }) => {
  const res = await fetch(`https://api.binance.com/api/v3/depth?symbol=${encodeURIComponent(data.symbol)}&limit=10`, { signal: AbortSignal.timeout(10000) });
  if (!res.ok) throw new Error("Livro de ordens indisponível");
  return z.object({ bids: z.array(z.tuple([z.string(), z.string()])), asks: z.array(z.tuple([z.string(), z.string()])) }).parse(await res.json());
});
