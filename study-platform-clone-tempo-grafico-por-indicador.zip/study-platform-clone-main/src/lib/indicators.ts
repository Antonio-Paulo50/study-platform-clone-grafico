import { z } from "zod";
import { ADX, MFI, SMA, EMA, PSAR, Stochastic, BollingerBands, CCI, HeikinAshi } from "technicalindicators";

const comparison = z.enum(["cross_up", "cross_down", "above", "below"]);

export const indicatorConfigSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("rsi"),
    period: z.number().int().min(2).max(50),
    condition: z.enum(["cross_up", "cross_down", "above", "below"]),
    level: z.number().min(1).max(99),
  }),
  z.object({
    type: z.literal("macd"),
    fast: z.number().int().min(2).max(50),
    slow: z.number().int().min(3).max(100),
    signal: z.number().int().min(2).max(50),
    condition: z.enum(["cross_up", "cross_down"]),
  }),
  z.object({
    type: z.literal("bb"),
    period: z.number().int().min(5).max(50),
    stdDev: z.number().min(0.5).max(4),
    condition: z.enum(["below_lower", "above_upper", "cross_up_lower"]),
  }),
  z.object({ type: z.literal("ultimate"), fast: z.number().int().min(2).max(50), middle: z.number().int().min(3).max(100), slow: z.number().int().min(4).max(200), condition: comparison, level: z.number().min(0).max(100) }),
  z.object({ type: z.literal("cci"), period: z.number().int().min(2).max(100), level: z.number().min(-500).max(500), condition: comparison }),
  z.object({ type: z.literal("heikin_ashi"), count: z.number().int().min(1).max(10), condition: z.enum(["bullish", "bearish", "turn_bullish", "turn_bearish"]) }),
  z.object({ type: z.literal("adx"), period: z.number().int().min(2).max(100), condition: comparison, level: z.number().min(0).max(100) }),
  z.object({ type: z.literal("mfi"), period: z.number().int().min(2).max(100), condition: comparison, level: z.number().min(0).max(100) }),
  z.object({ type: z.literal("ma"), method: z.enum(["sma", "ema"]), fast: z.number().int().min(2).max(100), slow: z.number().int().min(3).max(200), condition: comparison }),
  z.object({ type: z.literal("sar"), step: z.number().min(0.001).max(0.1), max: z.number().min(0.01).max(1), condition: comparison }),
  z.object({ type: z.literal("bb_percent"), period: z.number().int().min(5).max(100), stdDev: z.number().min(0.5).max(4), level: z.number().min(-200).max(300), condition: comparison }),
  z.object({ type: z.literal("stochastic"), period: z.number().int().min(2).max(100), smoothing: z.number().int().min(1).max(20), signal: z.number().int().min(1).max(20), target: z.enum(["level", "signal"]), level: z.number().min(0).max(100), condition: comparison }),
  z.object({
    type: z.literal("price_change"),
    hours: z.number().int().min(1).max(72),
    pct: z.number().min(0.1).max(50),
    condition: z.enum(["drop", "rise"]),
  }),
]).refine((v) => (v.type !== "macd" && v.type !== "ma") || v.fast < v.slow, "O período rápido deve ser menor que o lento").refine((v) => v.type !== "sar" || v.step <= v.max, "O passo deve ser menor ou igual ao máximo").refine(v => v.type !== "ultimate" || (v.fast < v.middle && v.middle < v.slow), "Use períodos crescentes no Ultimate Oscillator");

export type IndicatorConfig = z.infer<typeof indicatorConfigSchema>;
export type IndicatorType = IndicatorConfig["type"];

export const DEFAULT_INDICATORS: Record<IndicatorType, IndicatorConfig> = {
  ultimate: { type: "ultimate", fast: 7, middle: 14, slow: 28, condition: "cross_up", level: 30 },
  cci: { type: "cci", period: 20, level: -100, condition: "cross_up" },
  heikin_ashi: { type: "heikin_ashi", count: 1, condition: "turn_bullish" },
  adx: { type: "adx", period: 14, condition: "above", level: 25 },
  mfi: { type: "mfi", period: 14, condition: "cross_up", level: 20 },
  ma: { type: "ma", method: "ema", fast: 9, slow: 21, condition: "cross_up" },
  sar: { type: "sar", step: 0.02, max: 0.2, condition: "cross_up" },
  bb_percent: { type: "bb_percent", period: 20, stdDev: 2, level: 0, condition: "cross_up" },
  stochastic: { type: "stochastic", period: 14, smoothing: 3, signal: 3, target: "level", level: 20, condition: "cross_up" },
  rsi: { type: "rsi", period: 14, condition: "cross_up", level: 30 },
  macd: { type: "macd", fast: 12, slow: 26, signal: 9, condition: "cross_up" },
  bb: { type: "bb", period: 20, stdDev: 2, condition: "below_lower" },
  price_change: { type: "price_change", hours: 24, pct: 3, condition: "drop" },
};

export const INDICATOR_NAMES: Record<IndicatorType, string> = {
  ultimate: "Ultimate Oscillator", cci: "Commodity Channel Index", heikin_ashi: "Heikin Ashi",
  adx: "ADX", mfi: "MFI", ma: "Médias móveis", sar: "SAR Parabolic", bb_percent: "BB%", stochastic: "Stochastic",
  rsi: "RSI",
  macd: "MACD",
  bb: "Bandas de Bollinger",
  price_change: "Variação de preço",
};

export const CONDITION_LABELS: Record<string, string> = {
  bullish: "Candles de alta", bearish: "Candles de baixa", turn_bullish: "Virada para alta", turn_bearish: "Virada para baixa",
  cross_up: "Cruzando para cima",
  cross_down: "Cruzando para baixo",
  above: "Acima de",
  below: "Abaixo de",
  below_lower: "Preço abaixo da banda inferior",
  above_upper: "Preço acima da banda superior",
  cross_up_lower: "Preço cruzando para cima a banda inferior",
  drop: "Queda de pelo menos",
  rise: "Alta de pelo menos",
};

export function describeIndicator(c: IndicatorConfig | null | undefined): string {
  if (!c) return "Imediato";
  switch (c.type) {
    case "ultimate": return `Ultimate ${c.fast}/${c.middle}/${c.slow} · ${CONDITION_LABELS[c.condition]} ${c.level}`;
    case "cci": return `CCI ${c.period} · ${CONDITION_LABELS[c.condition]} ${c.level}`;
    case "heikin_ashi": return `Heikin Ashi · ${CONDITION_LABELS[c.condition]} · ${c.count} candle(s)`;
    case "adx": case "mfi":
      return `${INDICATOR_NAMES[c.type]} ${c.period} ${CONDITION_LABELS[c.condition]?.toLowerCase()} ${c.level}`;
    case "ma": return `${c.method.toUpperCase()} ${c.fast}/${c.slow} · ${CONDITION_LABELS[c.condition]?.toLowerCase()}`;
    case "sar": return `SAR ${c.step}/${c.max} · preço ${CONDITION_LABELS[c.condition]?.toLowerCase()} SAR`;
    case "bb_percent": return `BB% ${c.period}/${c.stdDev} · ${CONDITION_LABELS[c.condition]?.toLowerCase()} ${c.level}%`;
    case "stochastic": return `Stochastic ${c.period}/${c.smoothing}/${c.signal} · %K ${CONDITION_LABELS[c.condition]?.toLowerCase()} ${c.target === "signal" ? "%D" : c.level}`;
    case "rsi":
      return `RSI ${c.period} ${CONDITION_LABELS[c.condition]?.toLowerCase()} ${c.level}`;
    case "macd":
      return `MACD ${c.fast}/${c.slow}/${c.signal} ${c.condition === "cross_up" ? "cruzando sinal para cima" : "cruzando sinal para baixo"}`;
    case "bb":
      return `BB ${c.period}/${c.stdDev} · ${CONDITION_LABELS[c.condition]?.toLowerCase()}`;
    case "price_change":
      return `${c.condition === "drop" ? "Queda" : "Alta"} ≥ ${c.pct}% em ${c.hours}h`;
  }
}

// ---------- Calculations (hourly closes, oldest first) ----------

function rsiSeries(closes: number[], period: number): number[] {
  const out: number[] = [];
  if (closes.length <= period) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = (closes[i] ?? 0) - (closes[i - 1] ?? 0);
    if (d >= 0) gain += d; else loss -= d;
  }
  gain /= period; loss /= period;
  out.push(loss === 0 ? 100 : 100 - 100 / (1 + gain / loss));
  for (let i = period + 1; i < closes.length; i++) {
    const d = (closes[i] ?? 0) - (closes[i - 1] ?? 0);
    gain = (gain * (period - 1) + Math.max(d, 0)) / period;
    loss = (loss * (period - 1) + Math.max(-d, 0)) / period;
    out.push(loss === 0 ? 100 : 100 - 100 / (1 + gain / loss));
  }
  return out;
}

function ema(values: number[], period: number): number[] {
  const k = 2 / (period + 1);
  const out: number[] = [];
  values.forEach((v, i) => out.push(i === 0 ? v : v * k + (out[i - 1] ?? 0) * (1 - k)));
  return out;
}

function bands(closes: number[], period: number, mult: number) {
  const slice = closes.slice(-period);
  const mean = slice.reduce((s, v) => s + v, 0) / slice.length;
  const sd = Math.sqrt(slice.reduce((s, v) => s + (v - mean) ** 2, 0) / slice.length);
  return { lower: mean - mult * sd, upper: mean + mult * sd };
}

/** Returns true when the start condition is met on the latest closed candle. */
export function evaluateIndicator(c: IndicatorConfig, closes: number[]): boolean {
  const n = closes.length;
  if (n < 3) return false;
  switch (c.type) {
    case "ultimate": case "cci": case "heikin_ashi": case "adx": case "mfi": case "ma": case "sar": case "bb_percent": case "stochastic": return false;
    case "rsi": {
      const r = rsiSeries(closes, c.period);
      if (r.length < 2) return false;
      const prev = (r[r.length - 2] ?? 0), cur = (r[r.length - 1] ?? 0);
      if (c.condition === "cross_up") return prev < c.level && cur >= c.level;
      if (c.condition === "cross_down") return prev > c.level && cur <= c.level;
      if (c.condition === "above") return cur > c.level;
      return cur < c.level;
    }
    case "macd": {
      if (n < c.slow + c.signal) return false;
      const fast = ema(closes, c.fast), slow = ema(closes, c.slow);
      const macd = fast.map((v, i) => v - (slow[i] ?? 0));
      const sig = ema(macd, c.signal);
      const prevDiff = (macd[n - 2] ?? 0) - (sig[n - 2] ?? 0), curDiff = (macd[n - 1] ?? 0) - (sig[n - 1] ?? 0);
      return c.condition === "cross_up" ? prevDiff < 0 && curDiff >= 0 : prevDiff > 0 && curDiff <= 0;
    }
    case "bb": {
      if (n < c.period + 1) return false;
      const cur = (closes[n - 1] ?? 0), prev = (closes[n - 2] ?? 0);
      const now = bands(closes, c.period, c.stdDev);
      if (c.condition === "below_lower") return cur < now.lower;
      if (c.condition === "above_upper") return cur > now.upper;
      const before = bands(closes.slice(0, -1), c.period, c.stdDev);
      return prev < before.lower && cur >= now.lower;
    }
    case "price_change": {
      if (n <= c.hours) return false;
      const change = (((closes[n - 1] ?? 0) - (closes[n - 1 - c.hours] ?? 0)) / (closes[n - 1 - c.hours] ?? 0)) * 100;
      return c.condition === "drop" ? change <= -c.pct : change >= c.pct;
    }
  }
}


export type MarketCandle = { time: number; open: number; high: number; low: number; close: number; volume: number };

function compareSeries(condition: "cross_up" | "cross_down" | "above" | "below", values: number[]): boolean {
  const current = values.at(-1), previous = values.at(-2);
  if (current === undefined || previous === undefined || !Number.isFinite(current) || !Number.isFinite(previous)) return false;
  if (condition === "above") return current > 0;
  if (condition === "below") return current < 0;
  return condition === "cross_up" ? previous <= 0 && current > 0 : previous >= 0 && current < 0;
}

export function evaluateCandleIndicator(c: IndicatorConfig, candles: MarketCandle[], timeframe: Timeframe = "1h"): boolean {
  if (candles.length < 3) return false;
  const high = candles.map(v => v.high), low = candles.map(v => v.low), close = candles.map(v => v.close), volume = candles.map(v => v.volume);
  switch (c.type) {
    case "cci": return compareSeries(c.condition, CCI.calculate({ high, low, close, period: c.period }).map(v => v - c.level));
    case "heikin_ashi": {
      const ha = HeikinAshi.calculate({ open: candles.map(v => v.open), high, low, close, volume, timestamp: candles.map(v => v.time) });
      const directions = (ha.close ?? []).map((v, i) => v - (ha.open?.[i] ?? NaN));
      if (directions.length < c.count + 1) return false;
      const bullish = c.condition === "bullish" || c.condition === "turn_bullish";
      const matching = directions.slice(-c.count).every(v => bullish ? v > 0 : v < 0);
      if (!matching) return false;
      if (c.condition.startsWith("turn_")) { const previous = directions.at(-c.count - 1); return previous !== undefined && (bullish ? previous <= 0 : previous >= 0); }
      return true;
    }
    case "ultimate": {
      // Ultimate Oscillator has no implementation in technicalindicators.
      const bp = candles.slice(1).map((v, i) => v.close - Math.min(v.low, candles[i]?.close ?? v.close));
      const tr = candles.slice(1).map((v, i) => Math.max(v.high, candles[i]?.close ?? v.close) - Math.min(v.low, candles[i]?.close ?? v.close));
      const values: number[] = [];
      for (let end = c.slow; end <= bp.length; end++) {
        const avg = (period: number) => { const pressure = bp.slice(end - period, end).reduce((a,b) => a+b,0); const range = tr.slice(end - period, end).reduce((a,b) => a+b,0); return range > 0 ? pressure / range : NaN; };
        values.push(100 * (4 * avg(c.fast) + 2 * avg(c.middle) + avg(c.slow)) / 7 - c.level);
      }
      return compareSeries(c.condition, values);
    }
    case "price_change": {
      const latest = candles.at(-1); if (!latest) return false;
      const earlier = [...candles].reverse().find(v => v.time <= latest.time - c.hours * 3600000);
      if (!earlier || earlier.close <= 0) return false;
      const change = (latest.close / earlier.close - 1) * 100;
      return c.condition === "drop" ? change <= -c.pct : change >= c.pct;
    }
    case "adx": return compareSeries(c.condition, ADX.calculate({ high, low, close, period: c.period }).map(v => v.adx - c.level));
    case "mfi": return compareSeries(c.condition, MFI.calculate({ high, low, close, volume, period: c.period }).map(v => v - c.level));
    case "ma": {
      const calc = c.method === "ema" ? EMA : SMA;
      const fast = calc.calculate({ values: close, period: c.fast }), slow = calc.calculate({ values: close, period: c.slow });
      return compareSeries(c.condition, slow.map((v, i) => (fast[fast.length - slow.length + i] ?? NaN) - v));
    }
    case "sar": { const series = PSAR.calculate({ high, low, step: c.step, max: c.max }); return compareSeries(c.condition, series.map((v, i) => (close[close.length - series.length + i] ?? NaN) - v)); }
    case "bb_percent": return compareSeries(c.condition, BollingerBands.calculate({ values: close, period: c.period, stdDev: c.stdDev }).map(v => v.pb * 100 - c.level));
    case "stochastic": {
      const raw = Stochastic.calculate({ high, low, close, period: c.period, signalPeriod: 1 }).map(v => v.k);
      const k = SMA.calculate({ values: raw, period: c.smoothing });
      if (c.target === "level") return compareSeries(c.condition, k.map(v => v - c.level));
      const d = SMA.calculate({ values: k, period: c.signal });
      return compareSeries(c.condition, d.map((v, i) => (k[k.length - d.length + i] ?? NaN) - v));
    }
    default: return evaluateIndicator(c, close);
  }
}

export const TIMEFRAMES = { "3m": "3 minutos", "5m": "5 minutos", "15m": "15 minutos", "30m": "30 minutos", "1h": "1 hora", "4h": "4 horas", "1d": "1 dia", "1w": "1 semana" } as const;
export type Timeframe = keyof typeof TIMEFRAMES;
export const timeframeSchema = z.enum(["3m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"]);
export const TIMEFRAME_MS: Record<Timeframe, number> = { "3m": 180000, "5m": 300000, "15m": 900000, "30m": 1800000, "1h": 3600000, "4h": 14400000, "1d": 86400000, "1w": 604800000 };

const timeframeField = z.object({ timeframe: timeframeSchema.default("1h") });
export const indicatorConfigsSchema = z.array(indicatorConfigSchema.and(timeframeField.partial())).min(1).max(3);

/** Indicador com o seu próprio tempo gráfico (opcional em dados legados, que usam o tempo do bot). */
export type IndicatorEntry = IndicatorConfig & { timeframe?: Timeframe };

export const DEFAULT_TIMEFRAME: Timeframe = "1h";

/** Tempo gráfico efetivo de um indicador: o próprio, ou o do bot (dados legados), ou 1h. */
export function entryTimeframe(c: { timeframe?: unknown } | null | undefined, fallback: Timeframe = DEFAULT_TIMEFRAME): Timeframe {
  const parsed = timeframeSchema.safeParse(c?.timeframe);
  return parsed.success ? parsed.data : fallback;
}

/** Descrição do indicador seguida do tempo gráfico, ex.: "RSI 14 cruzando para cima 30 · 1 hora". */
export function describeEntry(c: IndicatorEntry | null | undefined, fallback: Timeframe = DEFAULT_TIMEFRAME): string {
  if (!c) return describeIndicator(c);
  return `${describeIndicator(c)} · ${TIMEFRAMES[entryTimeframe(c, fallback)]}`;
}
