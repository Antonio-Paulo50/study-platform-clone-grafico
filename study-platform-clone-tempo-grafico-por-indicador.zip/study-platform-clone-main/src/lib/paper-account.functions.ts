import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const paperActionSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("rename"), name: z.string().trim().min(1).max(60) }),
  z.object({ action: z.literal("add"), amount: z.number().finite().min(1).max(1000000) }),
  z.object({ action: z.literal("reset"), confirmation: z.literal("RESETAR") }),
]);
export const getPaperAccount = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const [profile, balances, deals] = await Promise.all([
    context.supabase.from("profiles").select("paper_account_name").eq("id", context.userId).single(),
    context.supabase.from("paper_balances").select("currency,balance").eq("user_id", context.userId),
    context.supabase.from("deals").select("invested,status").eq("user_id", context.userId),
  ]);
  if (profile.error || balances.error || deals.error) throw new Error("Não foi possível carregar a conta");
  return { name: profile.data.paper_account_name, balance: Number(balances.data.find(v => v.currency === "USDT")?.balance ?? 0), invested: deals.data.filter(v => v.status === "open").reduce((sum,v) => sum + Number(v.invested),0), historyCount: deals.data.length };
});
export const managePaperAccount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator(data => paperActionSchema.parse(data)).handler(async ({ data, context }) => {
  const { data: balance, error } = await context.supabase.rpc("manage_paper_account", { _action: data.action, _amount: data.action === "add" ? data.amount : 0, ...(data.action === "rename" ? { _name: data.name } : {}) });
  if (error) throw new Error("Não foi possível atualizar a conta de simulação");
  return { balance: Number(balance ?? 0) };
});