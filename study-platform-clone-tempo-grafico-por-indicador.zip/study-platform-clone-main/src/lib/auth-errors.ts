// Tradução das mensagens de erro de autenticação (Supabase Auth) para português.
// Usa o `code` do erro quando existe e cai para trechos da mensagem como reserva.

type AuthLikeError = {
  message?: string;
  code?: string;
  status?: number;
  reasons?: string[];
};

const M = {
  invalidCredentials: "E-mail ou senha incorretos.",
  emailNotConfirmed:
    "Seu e-mail ainda não foi confirmado. Confirme pelo link que enviamos ou reenvie o e-mail.",
  userExists: "Este e-mail já está cadastrado. Entre ou recupere a senha.",
  emailRateLimit: "Muitos e-mails enviados em pouco tempo. Aguarde alguns minutos e tente de novo.",
  requestRateLimit: "Muitas tentativas seguidas. Aguarde um pouco e tente novamente.",
  samePassword: "A nova senha precisa ser diferente da senha atual.",
  emailInvalid: "Esse endereço de e-mail não é válido ou não é aceito.",
  signupDisabled: "O cadastro de novas contas está desativado no momento.",
  linkExpired: "O link expirou ou já foi usado. Solicite um novo.",
  sessionExpired: "Sua sessão expirou. Entre novamente.",
  serverError: "Erro inesperado no servidor. Tente novamente em instantes.",
  network: "Sem conexão com o servidor. Verifique sua internet e tente novamente.",
} as const;

const BY_CODE: Record<string, string> = {
  invalid_credentials: M.invalidCredentials,
  email_not_confirmed: M.emailNotConfirmed,
  user_already_exists: M.userExists,
  email_exists: M.userExists,
  user_not_found: "Não encontramos uma conta com esse e-mail.",
  signup_disabled: M.signupDisabled,
  email_provider_disabled: "O cadastro por e-mail está desativado no momento.",
  email_address_invalid: M.emailInvalid,
  email_address_not_authorized: "Esse endereço de e-mail não está autorizado a receber mensagens.",
  validation_failed: "Os dados informados não são válidos. Confira e tente novamente.",
  same_password: M.samePassword,
  over_email_send_rate_limit: M.emailRateLimit,
  over_request_rate_limit: M.requestRateLimit,
  over_sms_send_rate_limit: M.requestRateLimit,
  otp_expired: M.linkExpired,
  session_expired: M.sessionExpired,
  session_not_found: M.sessionExpired,
  refresh_token_not_found: M.sessionExpired,
  user_banned: "Esta conta está temporariamente bloqueada.",
  provider_disabled: "Esse método de login não está habilitado.",
  captcha_failed: "Falha na verificação de segurança (captcha). Tente novamente.",
  reauthentication_needed: "Por segurança, entre novamente para concluir essa ação.",
  unexpected_failure: M.serverError,
};

const BY_MESSAGE: Array<[RegExp, string]> = [
  [/invalid login credentials/i, M.invalidCredentials],
  [/email not confirmed/i, M.emailNotConfirmed],
  [/user already registered|already been registered/i, M.userExists],
  [/rate limit|too many requests|after \d+ seconds?/i, M.emailRateLimit],
  [/new password should be different/i, M.samePassword],
  [/unable to validate email address|invalid format/i, M.emailInvalid],
  [/signups? not allowed|signup is disabled/i, M.signupDisabled],
  [/token has expired|otp.*expired|link.*expired|invalid or has expired/i, M.linkExpired],
  [/failed to fetch|networkerror|network request failed|load failed/i, M.network],
];

function passwordMessage(err: AuthLikeError): string {
  const reasons = err.reasons ?? [];
  if (reasons.includes("pwned")) {
    return "Essa senha apareceu em vazamentos de dados e é considerada insegura. Escolha outra, diferente das que você usa em outros sites.";
  }
  const parts: string[] = [];
  if (reasons.includes("length")) parts.push("é curta demais");
  if (reasons.includes("characters"))
    parts.push("precisa misturar letras maiúsculas, minúsculas, números e símbolos");
  if (parts.length) return `Senha fraca: ${parts.join(" e ")}.`;
  return "Essa senha é fraca ou fácil de adivinhar. Escolha uma mais longa, misturando letras, números e símbolos.";
}

export function translateAuthError(
  error: unknown,
  fallback = "Algo deu errado. Tente novamente.",
): string {
  if (!error) return fallback;
  const err = (typeof error === "object" ? error : { message: String(error) }) as AuthLikeError;
  const message = err.message ?? "";

  if (
    err.code === "weak_password" ||
    /weak and easy to guess|password should be at least|password is known to be weak/i.test(message)
  ) {
    return passwordMessage(err);
  }
  const byCode = err.code ? BY_CODE[err.code] : undefined;
  if (byCode) return byCode;
  for (const [re, text] of BY_MESSAGE) if (re.test(message)) return text;
  if (err.status === 429) return M.requestRateLimit;
  if (err.status && err.status >= 500) return M.serverError;
  return fallback;
}
