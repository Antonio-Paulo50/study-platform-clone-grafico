import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { BOT_LIMITS } from "@/lib/bot-limits";
import { entryTimeframe, evaluateCandleIndicator, indicatorConfigSchema, indicatorConfigsSchema, timeframeSchema, TIMEFRAME_MS, type Timeframe, type MarketCandle } from "@/lib/indicators";

// Maps trading pairs to CoinGecko coin ids
const PAIR_TO_COIN: Record<string, string> = {
  "BTC/USDT": "bitcoin",
  "ETH/USDT": "ethereum",
  "BCH/USDT": "bitcoin-cash",
  "XRP/USDT": "ripple",
  "LTC/USDT": "litecoin",
  "TRX/USDT": "tron",
  "ETC/USDT": "ethereum-classic",
  "BNB/USDT": "binancecoin",
  "SOL/USDT": "solana",
  "ADA/USDT": "cardano",
  "DOGE/USDT": "dogecoin",
  "AVAX/USDT": "avalanche-2",
  "LINK/USDT": "chainlink",
  "DOT/USDT": "polkadot",
  "MATIC/USDT": "matic-network",
  "NEAR/USDT": "near",
  "ATOM/USDT": "cosmos",
  "SHIB/USDT": "shiba-inu",
  "UNI/USDT": "uniswap",
  "SUI/USDT": "sui",
  "APT/USDT": "aptos",
  "ICP/USDT": "internet-computer",
  "FIL/USDT": "filecoin",
  "RENDER/USDT": "render-token",
  "PEPE/USDT": "pepe",
};

export const SUPPORTED_PAIRS = Object.keys(PAIR_TO_COIN);

export const PAIR_CATEGORIES: Record<string, string[]> = {
  "Binance Top USDT": ["BTC/USDT", "ETH/USDT", "BCH/USDT", "XRP/USDT", "LTC/USDT", "TRX/USDT", "ETC/USDT"],
  "Major": ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT"],
  "Layer 1": ["ADA/USDT", "AVAX/USDT", "DOT/USDT", "NEAR/USDT", "ATOM/USDT", "SUI/USDT", "APT/USDT", "ICP/USDT"],
  "DeFi / Infra": ["LINK/USDT", "UNI/USDT", "RENDER/USDT", "FIL/USDT"],
  "Pagamentos": ["BCH/USDT", "XRP/USDT", "LTC/USDT", "TRX/USDT", "ETC/USDT"],
  "Meme": ["DOGE/USDT", "SHIB/USDT", "PEPE/USDT"],
};

async function fetchPrices(coinIds: string[]): Promise<Record<string, number>> {
  const ids = [...new Set(coinIds)].join(",");
  const res = await fetch(
    `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) throw new Error("Falha ao buscar preços");
  const json = (await res.json()) as Record<string, { usd: number }>;
  const out: Record<string, number> = {};
  for (const [id, val] of Object.entries(json)) out[id] = val.usd;
  return out;
}

const isValidSpotUsdtPair = (p: string) => /^[A-Z0-9]{2,15}\/USDT$/.test(p);

export const createBotSchema = z.object({
  name: z.string().trim().min(1).max(60),
  pair: z.string().refine(isValidSpotUsdtPair, "Par USDT Spot inválido"),
  pairs: z.array(z.string().refine(isValidSpotUsdtPair, "Par USDT Spot inválido")).min(BOT_LIMITS.pairsPerBot.min).max(BOT_LIMITS.pairsPerBot.max).refine(p => new Set(p).size === p.length, "Pares repetidos").optional(),
  timeframe: timeframeSchema.default("1h"),
  indicatorConfigs: indicatorConfigsSchema.optional(),
  baseOrderSize: z.number().positive().max(BOT_LIMITS.orderSize.max),
  safetyOrderSize: z.number().positive().max(BOT_LIMITS.orderSize.max),
  maxSafetyOrders: z.number().int().min(BOT_LIMITS.maxSafetyOrders.min).max(BOT_LIMITS.maxSafetyOrders.max),
  priceDeviationPct: z.number().min(BOT_LIMITS.priceDeviationPct.min).max(BOT_LIMITS.priceDeviationPct.max),
  takeProfitPct: z.number().min(BOT_LIMITS.takeProfitPct.min).max(BOT_LIMITS.takeProfitPct.max),
  stopLossPct: z.number().min(BOT_LIMITS.stopLossPct.min).max(BOT_LIMITS.stopLossPct.max).optional(),
  startCondition: z.enum(["immediate", "indicator"]).default("immediate"),
  indicatorConfig: indicatorConfigSchema.optional(),
}).refine((v) => v.startCondition === "immediate" || (v.indicatorConfigs || v.indicatorConfig), "Configure o indicador");

/** `bots.timeframe` guarda o tempo do primeiro indicador; cada indicador mantém o seu próprio em `indicator_configs`. */
function botTimeframe(data: { timeframe: Timeframe; startCondition: string; indicatorConfigs?: { timeframe?: Timeframe }[] }): Timeframe {
  return data.startCondition === "indicator" ? entryTimeframe(data.indicatorConfigs?.[0], data.timeframe) : data.timeframe;
}

async function fetchCandles(pair: string, timeframe: Timeframe): Promise<MarketCandle[]> {
  const symbol = pair.replace("/", "");
  if (!isValidSpotUsdtPair(pair)) return [];
  try {
    const res = await fetch(`https://api.binance.com/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${timeframe}&limit=1000`, { signal: AbortSignal.timeout(10000) });
    if (!res.ok) return [];
    const rows = z.array(z.array(z.union([z.number(), z.string()]))).parse(await res.json());
    const candles = rows.filter(row => Number(row[6]) < Date.now()).map(row => ({ time: Number(row[0]), open: Number(row[1]), high: Number(row[2]), low: Number(row[3]), close: Number(row[4]), volume: Number(row[5]) }));
    if (candles.some((v, i) => !Object.values(v).every(Number.isFinite) || v.close <= 0 || v.high < v.low || v.volume < 0 || (i > 0 && v.time !== (candles[i - 1]?.time ?? 0) + TIMEFRAME_MS[timeframe]))) return [];
    if ((candles.at(-1)?.time ?? 0) < Date.now() - TIMEFRAME_MS[timeframe] * 2) return [];
    return candles;
  } catch { return []; }
}

export const createBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => createBotSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: balance } = await supabase
      .from("paper_balances")
      .select("balance")
      .eq("user_id", userId)
      .eq("currency", "USDT")
      .single();

    const required = data.baseOrderSize * (data.pairs?.length ?? 1);
    if (!balance || Number(balance.balance) < required) {
      throw new Error("Saldo fictício insuficiente para a ordem base");
    }

    const { data: bot, error } = await supabase
      .from("bots")
      .insert({
        user_id: userId,
        name: data.name,
        pair: data.pairs?.[0] ?? data.pair,
        strategy: "dca",
        pairs: data.pairs ?? [data.pair],
        timeframe: botTimeframe(data),
        indicator_configs: data.startCondition === "indicator" ? data.indicatorConfigs ?? (data.indicatorConfig ? [data.indicatorConfig] : []) : [],
        base_order_size: data.baseOrderSize,
        safety_order_size: data.safetyOrderSize,
        max_safety_orders: data.maxSafetyOrders,
        price_deviation_pct: data.priceDeviationPct,
        take_profit_pct: data.takeProfitPct,
        stop_loss_pct: data.stopLossPct ?? null,
        start_condition: data.startCondition,
        indicator_config: data.startCondition === "indicator" ? (data.indicatorConfigs?.[0] ?? data.indicatorConfig ?? null) : null,
      })
      .select()
      .single();

    if (error) throw new Error(error.message);
    return bot;
  });

export const updateBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => ({ ...createBotSchema.parse(data), botId: z.string().uuid().parse((data as { botId?: unknown })?.botId) }))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: existing, error: readError } = await supabase.from("bots").select("pair,pairs").eq("id", data.botId).eq("user_id", userId).single();
    if (readError || !existing) throw new Error("Bot não encontrado");
    if (JSON.stringify([...(existing.pairs.length ? existing.pairs : [existing.pair])].sort()) !== JSON.stringify([...(data.pairs ?? [data.pair])].sort())) {
      const { count, error: dealError } = await supabase.from("deals").select("id", { count: "exact", head: true }).eq("bot_id", data.botId).eq("user_id", userId).eq("status", "open");
      if (dealError) throw new Error("Não foi possível verificar as operações abertas");
      if (count) throw new Error("Não altere o par enquanto houver operação aberta");
    }
    const { data: bot, error } = await supabase
      .from("bots")
      .update({
        name: data.name,
        pair: data.pairs?.[0] ?? data.pair,
        pairs: data.pairs ?? [data.pair],
        timeframe: botTimeframe(data),
        indicator_configs: data.startCondition === "indicator" ? data.indicatorConfigs ?? (data.indicatorConfig ? [data.indicatorConfig] : []) : [],
        base_order_size: data.baseOrderSize,
        safety_order_size: data.safetyOrderSize,
        max_safety_orders: data.maxSafetyOrders,
        price_deviation_pct: data.priceDeviationPct,
        take_profit_pct: data.takeProfitPct,
        stop_loss_pct: data.stopLossPct ?? null,
        start_condition: data.startCondition,
        indicator_config: data.startCondition === "indicator" ? (data.indicatorConfigs?.[0] ?? data.indicatorConfig ?? null) : null,
      })
      .eq("id", data.botId)
      .eq("user_id", userId)
      .select()
      .single();
    if (error) throw new Error("Não foi possível salvar o bot");
    return bot;
  });

export const setBotStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) =>
    z.object({ botId: z.string().uuid(), status: z.enum(["active", "paused", "stopped"]) }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("bots")
      .update({ status: data.status })
      .eq("id", data.botId)
      .eq("user_id", userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteBot = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data) => z.object({ botId: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: refunded, error } = await supabase.rpc("delete_bot_and_refund", {
      _bot_id: data.botId,
    });
    if (error) throw new Error(error.message);
    return { ok: true, refunded: Number(refunded ?? 0) };
  });

/**
 * Paper-trading engine tick. For each active bot of the user:
 * - opens a deal at market price if none is open (deducts base order from balance)
 * - averages down with safety orders when price drops by the deviation %
 * - closes the deal at take profit or stop loss, crediting proceeds
 */
export const runSimulation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const { data: bots, error } = await supabase
      .from("bots")
      .select("*")
      .eq("user_id", userId)
      .eq("status", "active");
    if (error) throw new Error(error.message);
    if (!bots?.length) return { opened: 0, closed: 0, safetyOrders: 0, waiting: 0 };

    const allPairs = [...new Set(bots.flatMap(b => b.pairs.length ? b.pairs : [b.pair]))];
    const symbols = allPairs.map(p => p.replace("/", ""));
    const quotesResponse = await fetch(`https://api.binance.com/api/v3/ticker/bookTicker?symbols=${encodeURIComponent(JSON.stringify(symbols))}`, { signal: AbortSignal.timeout(10000) });
    if (!quotesResponse.ok) throw new Error("Cotações indisponíveis. Nenhuma operação executada.");
    const quotes = z.array(z.object({ symbol: z.string(), bidPrice: z.coerce.number().positive(), askPrice: z.coerce.number().positive() })).parse(await quotesResponse.json());
    const prices = Object.fromEntries(quotes.map(q => [q.symbol, q]));

    const { data: balanceRow } = await supabase
      .from("paper_balances")
      .select("*")
      .eq("user_id", userId)
      .eq("currency", "USDT")
      .single();
    let balance = Number(balanceRow?.balance ?? 0);

    const candlesCache: Record<string, MarketCandle[]> = {};
    let waiting = 0;
    let opened = 0;
    let closed = 0;
    let safetyOrders = 0;

    for (const bot of bots) {
      for (const pair of (bot.pairs.length ? bot.pairs : [bot.pair])) {
      const quote = prices[pair.replace("/", "")];
      if (!quote) continue;
      let price = quote.askPrice;

      const { data: openDeals } = await supabase
        .from("deals")
        .select("*")
        .eq("bot_id", bot.id)
        .eq("pair", pair)
        .eq("status", "open")
        .limit(1);
      const deal = openDeals?.[0];

      if (!deal) {
        const base = Number(bot.base_order_size);
        if (balance < base) continue;
        if (bot.start_condition === "indicator") {
          const parsed = indicatorConfigsSchema.safeParse(bot.indicator_configs);
          const legacy = indicatorConfigSchema.safeParse(bot.indicator_config);
          const configs = parsed.success ? parsed.data : legacy.success ? [legacy.data] : [];
          const interval = timeframeSchema.safeParse(bot.timeframe);
          if (!configs.length || !interval.success) { waiting++; continue; }
          // Cada indicador é avaliado nos candles do seu próprio tempo gráfico (legado: usa o tempo do bot).
          let allMet = true;
          for (const config of configs) {
            const tf = entryTimeframe(config, interval.data);
            const key = `${pair}:${tf}`;
            candlesCache[key] ??= await fetchCandles(pair, tf);
            if (!evaluateCandleIndicator(config, candlesCache[key] ?? [], tf)) { allMet = false; break; }
          }
          if (!allMet) { waiting++; continue; }
        }
        const { error: insErr } = await supabase.from("deals").insert({
          bot_id: bot.id,
          user_id: userId,
          pair,
          entry_price: price,
          invested: base,
          quantity: base / price,
        });
        if (insErr) continue;
        balance -= base;
        opened++;
        continue;
      }

      price = quote.bidPrice;
      const avgPrice = Number(deal.entry_price);
      const invested = Number(deal.invested);
      const quantity = Number(deal.quantity);
      const pnlPct = ((price - avgPrice) / avgPrice) * 100;
      const tp = Number(bot.take_profit_pct);
      const sl = bot.stop_loss_pct != null ? Number(bot.stop_loss_pct) : null;

      // Take profit / stop loss
      if (pnlPct >= tp || (sl != null && pnlPct <= -sl)) {
        const proceeds = quantity * price;
        const profit = proceeds - invested;
        await supabase
          .from("deals")
          .update({
            status: "completed",
            close_price: price,
            profit,
            closed_at: new Date().toISOString(),
          })
          .eq("id", deal.id);
        await supabase
          .from("bots")
          .update({ total_profit: Number(bot.total_profit) + profit })
          .eq("id", bot.id);
        bot.total_profit = Number(bot.total_profit) + profit;
        balance += proceeds;
        closed++;
        continue;
      }

      // Safety orders buy at best ask
      price = quote.askPrice;
      // Safety orders (averaging down)
      const used = deal.safety_orders_used;
      const deviation = Number(bot.price_deviation_pct);
      const nextTrigger = avgPrice * (1 - (deviation * (used + 1)) / 100);
      if (used < bot.max_safety_orders && price <= nextTrigger) {
        const soSize = Number(bot.safety_order_size);
        if (balance >= soSize) {
          const newInvested = invested + soSize;
          const newQuantity = quantity + soSize / price;
          await supabase
            .from("deals")
            .update({
              invested: newInvested,
              quantity: newQuantity,
              entry_price: newInvested / newQuantity,
              safety_orders_used: used + 1,
            })
            .eq("id", deal.id);
          balance -= soSize;
          safetyOrders++;
        }
      }
    }

    }

    if (balanceRow) {
      await supabase
        .from("paper_balances")
        .update({ balance, updated_at: new Date().toISOString() })
        .eq("id", balanceRow.id);
    }

    return { opened, closed, safetyOrders, waiting };
  });
