# Catálogo completo de pares Binance Spot USDT

## Escopo
Usar o documento **Binance Spot**, compatível com o mercado atual. Os dois documentos de futuros não serão aplicados. Manter a aparência existente e operar exclusivamente com saldo fictício, sem chaves de corretora, futuros, alavancagem ou vendas a descoberto.

**Referência visual:** seguir as imagens na área de pares: botão **Adicionar par**, lista suspensa com altura limitada e rolagem, campo de busca no topo e caixas de seleção. A busca por `all` encontrará os símbolos Spot disponíveis que contenham esse trecho; não criar pares apenas porque aparecem na imagem de futuros. Não reproduzir a conta Futures nem habilitar Short/Both mostrados na referência.

## Diagnóstico curto
Hoje, a seleção dos bots usa uma lista fixa de **10 pares**. A página Mercado consulta outra lista, obtida dos preços da Binance, sem consultar o cadastro oficial de pares. Portanto, ver um par no Mercado não significa conseguir selecioná-lo no bot.

| Requisito | Situação atual |
|---|---|
| Dados públicos Spot, sem chave de corretora | **OK** nas consultas Binance de preços e candles da simulação. Há consultas CoinGecko em outras telas. |
| Todos os pares USDT disponíveis | **PARCIAL**: Mercado lista pares a partir de preços; criação e edição limitam a seleção a 10 pares. |
| Cadastro oficial, status e permissão Spot | **AUSENTE**: não há consulta a `exchangeInfo`. |
| Busca por trecho na seleção, sem distinguir maiúsculas | **AUSENTE**: a seleção dos bots é uma grade de caixas de seleção sem busca. |
| Seleção múltipla e salvamento | **PARCIAL**: já existem e são compartilhados entre criação e edição; limite atual de 10 pares. Falta preservar a seleção entre buscas. |
| Símbolo original da Binance | **PARCIAL**: Mercado recebe o símbolo, mas os bots usam nomes como `BTC/USDT` e removem a barra para consultar preços. O livro de ordens limita nomes por uma regra de caracteres. |
| Ordenação por volume em USDT | **PARCIAL**: existe no Mercado, não na seleção dos bots. |
| Catálogo salvo, atualização central e recuperação de falhas | **AUSENTE**: não existe catálogo persistente compartilhado com atualização e tentativas graduais. |
| Validação ao salvar, retomar e simular | **PARCIAL**: validação contra a lista fixa; falta consultar disponibilidade e filtros oficiais. |
| Regras de preço, quantidade e valor mínimo | **AUSENTE**: a simulação não aplica filtros de negociação da Binance. |
| Pares independentes, carteira virtual compartilhada | **PARCIAL**: já há operações separadas por par, mas as alterações de saldo da simulação não são uma transação única protegida contra execução simultânea. |
| Suspensão ou remoção de pares | **AUSENTE**: falta detectar, impedir novas compras, pausar e avisar sem apagar histórico. |

## Plano por etapas
1. **Catálogo oficial e recuperação de falhas** — guardar todos os pares USDT e seus filtros, inclusive os indisponíveis. Marcar removidos sem apagar histórico. Usar o último catálogo válido quando a Binance falhar e mostrar aviso quando não existir nenhum catálogo salvo.
2. **Atualização compartilhada** — sincronizar ao primeiro acesso e quando vencido, com proteção contra consultas simultâneas. Prever atualização horária, compartilhada por todos os usuários, e atualização dos volumes a cada poucos minutos enquanto houver uso. A atualização horária representa 24 verificações por dia; pode aumentar o consumo do Lovable Cloud e detectar mudanças com até uma hora de atraso. Sem visitas nem publicação, não prometer execução contínua.
3. **Seleção na criação e edição** — utilizar o mesmo catálogo nas duas telas e seguir a imagem: **Adicionar par** abre uma lista suspensa com busca, caixas de seleção e rolagem, sem redesenhar o restante do formulário. Buscar trechos no símbolo e na moeda; priorizar resultado exato, início e depois meio do nome. Preservar pares marcados ao buscar outros ou fechar a lista, mostrar o total encontrado e ordenar a lista padrão por liquidez. Exibir stablecoins e demais pares permitidos normalmente, com opção de ocultar categorias identificáveis; não inventar classificações de tokens.
4. **Compatibilidade e segurança da simulação** — armazenar os símbolos oficiais, adaptar bots antigos sem perder configurações ou histórico e validar pares ao criar, editar, ativar e abrir novas operações. Aplicar filtros oficiais às novas ordens fictícias, arredondando quantidades corretamente e deixando eventual sobra na carteira. Atualizações de saldo e operações devem ser transacionais para não gastar o mesmo saldo duas vezes.
5. **Indisponibilidade e testes** — pausar bots afetados e informar os pares indisponíveis. Não inventar preço de encerramento de uma posição sem cotação; preservar posição e histórico até existir uma resolução explícita. Testar novos/removidos, mudanças de filtros, nomes atípicos, busca por trecho, seleção entre buscas, falha de rede e criação/edição com persistência.

## Detalhes técnicos
- Usar `exchangeInfo` Spot e a alternativa pública de dados da Binance quando necessário; nunca endpoints assinados.
- Persistir catálogo, filtros e estado da sincronização no Lovable Cloud. Cache de memória não será a fonte de verdade: a hospedagem não garante um servidor permanente nem memória compartilhada.
- Centralizar atualização com bloqueio e prazo de validade persistentes; manter o último estado em falhas e respeitar limites e backoff.
- Consultar dados internos por funções do servidor; caso haja atualização agendada por HTTP, proteger a escrita com segredo exclusivo do servidor, não com uma chave pública.
- Não criar centenas de conexões de preços. Manter consultas agrupadas aos símbolos necessários e reutilizar dados compartilhados; transmissão contínua exigiria um serviço dedicado, fora desta etapa.
- A aplicação atual não possui ordens pendentes nem saldo `locked`. Não criar ficticiamente esse estado: proteger os débitos efetivos por transação. Se ordens pendentes forem adicionadas no futuro, implementar reservas e cancelamento antes de habilitá-las.
- Verificar testes de catálogo e carteira, além do fluxo autenticado de criar, editar, recarregar e retomar um bot. Não resetar nem modificar fundos existentes para testar.

## Aprovação
Nenhuma mudança funcional será feita antes da aprovação deste plano. Esta entrega não inclui Grid, SmartTrade, negociação real nem futuros.