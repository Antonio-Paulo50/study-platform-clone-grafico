-- 0005_integrity_constraints.sql  (Fase 1 do plano de implementação)
--
-- Objetivo: impedir estados inválidos no banco SEM alterar o comportamento atual do app.
-- Pré-requisito: rode docs/diagnostics-phase1.sql e resolva qualquer linha retornada.
-- Idempotente: pode ser reaplicada. Aplique primeiro em um projeto Supabase de TESTE.
--
-- Rollback (manual):
--   DROP INDEX IF EXISTS public.deals_one_open_per_bot_pair;
--   ALTER TABLE public.deals DROP CONSTRAINT IF EXISTS deals_status_check, DROP CONSTRAINT IF EXISTS deals_positive_check;
--   ALTER TABLE public.paper_balances DROP CONSTRAINT IF EXISTS paper_balances_nonneg;
--   ALTER TABLE public.bots DROP CONSTRAINT IF EXISTS bots_status_check, DROP CONSTRAINT IF EXISTS bots_ranges_check, DROP CONSTRAINT IF EXISTS bots_pair_format_check;
--   (as funções e a política abaixo podem voltar às versões das migrações 0000, 0001 e 0004)

-- 1) CHECKs: criadas NOT VALID (não falham por dados legados) e depois validadas.
--    Se alguma validação falhar, o script emite WARNING e segue; corrija os dados e rode
--    ALTER TABLE ... VALIDATE CONSTRAINT <nome>; manualmente.
--    Os limites de bots_ranges_check devem espelhar src/lib/bot-limits.ts (há teste de consistência).
DO $$
DECLARE c record;
BEGIN
  FOR c IN
    SELECT * FROM (VALUES
      ('deals', 'deals_status_check',
        $d$CHECK (status IN ('open','completed'))$d$),
      ('deals', 'deals_positive_check',
        $d$CHECK (invested > 0 AND quantity > 0 AND entry_price > 0)$d$),
      ('paper_balances', 'paper_balances_nonneg',
        $d$CHECK (balance >= 0)$d$),
      ('bots', 'bots_status_check',
        $d$CHECK (status IN ('active','paused','stopped'))$d$),
      ('bots', 'bots_ranges_check',
        $d$CHECK (
          base_order_size > 0 AND safety_order_size > 0
          AND max_safety_orders BETWEEN 0 AND 10
          AND price_deviation_pct BETWEEN 0.1 AND 20
          AND take_profit_pct BETWEEN 0.1 AND 50
          AND (stop_loss_pct IS NULL OR stop_loss_pct BETWEEN 0.5 AND 80)
          AND timeframe IN ('3m','5m','15m','30m','1h','4h','1d','1w')
          AND cardinality(pairs) BETWEEN 1 AND 100
        )$d$),
      ('bots', 'bots_pair_format_check',
        $d$CHECK (pair ~ '^[A-Z0-9]{2,15}/USDT$')$d$)
    ) AS t(tbl, cname, def)
  LOOP
    IF NOT EXISTS (
      SELECT 1 FROM pg_constraint
      WHERE conname = c.cname AND conrelid = format('public.%I', c.tbl)::regclass
    ) THEN
      EXECUTE format('ALTER TABLE public.%I ADD CONSTRAINT %I %s NOT VALID', c.tbl, c.cname, c.def);
    END IF;
    BEGIN
      EXECUTE format('ALTER TABLE public.%I VALIDATE CONSTRAINT %I', c.tbl, c.cname);
    EXCEPTION WHEN check_violation THEN
      RAISE WARNING 'Constraint % NAO validada: ha linhas legadas que violam a regra. Corrija os dados e rode VALIDATE CONSTRAINT manualmente.', c.cname;
    END;
  END LOOP;
END $$;

-- 2) No máximo uma operação aberta por (bot, par). O app já trata erro de insert
--    (runSimulation faz `continue`), então a duplicata simplesmente deixa de ser criada.
DO $$
BEGIN
  CREATE UNIQUE INDEX IF NOT EXISTS deals_one_open_per_bot_pair
    ON public.deals (bot_id, pair) WHERE status = 'open';
EXCEPTION WHEN unique_violation THEN
  RAISE WARNING 'Indice deals_one_open_per_bot_pair NAO criado: existem operacoes abertas duplicadas por (bot, par). Resolva (docs/diagnostics-phase1.sql) e reaplique.';
END $$;

-- 3) Funções de conta/exclusão passam a SECURITY DEFINER (com auth.uid() e filtros explícitos).
--    Necessário para a Fase 3, quando o usuário perder UPDATE direto em paper_balances/deals.
--    A lógica é IDÊNTICA à das migrações 0004 e 0001, exceto a trava de linhas em delete_bot_and_refund.
CREATE OR REPLACE FUNCTION public.manage_paper_account(_action text, _amount numeric DEFAULT 0, _name text DEFAULT NULL)
RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE uid uuid := auth.uid(); result numeric;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  PERFORM 1 FROM public.paper_balances WHERE user_id = uid AND currency = 'USDT' FOR UPDATE;
  IF _action = 'rename' THEN
    IF _name IS NULL OR length(trim(_name)) < 1 OR length(trim(_name)) > 60 THEN RAISE EXCEPTION 'Nome inválido'; END IF;
    UPDATE public.profiles SET paper_account_name = trim(_name) WHERE id = uid;
  ELSIF _action = 'add' THEN
    IF _amount IS NULL OR _amount < 1 OR _amount > 1000000 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
    UPDATE public.paper_balances SET balance = balance + _amount, updated_at = now() WHERE user_id = uid AND currency = 'USDT';
  ELSIF _action = 'reset' THEN
    DELETE FROM public.deals WHERE user_id = uid;
    UPDATE public.bots SET total_profit = 0, status = 'paused' WHERE user_id = uid;
    UPDATE public.paper_balances SET balance = CASE WHEN currency = 'USDT' THEN 10000 ELSE 0 END, updated_at = now() WHERE user_id = uid;
  ELSE
    RAISE EXCEPTION 'Ação inválida';
  END IF;
  SELECT balance INTO result FROM public.paper_balances WHERE user_id = uid AND currency = 'USDT';
  RETURN result;
END;
$$;
REVOKE ALL ON FUNCTION public.manage_paper_account(text, numeric, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.manage_paper_account(text, numeric, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.delete_bot_and_refund(_bot_id uuid)
RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE uid uuid := auth.uid(); refunded numeric := 0;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  -- trava o bot e o saldo (ordem fixa: bots -> saldo) para evitar corrida com outras execuções
  PERFORM 1 FROM public.bots WHERE id = _bot_id AND user_id = uid FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Bot not found'; END IF;
  PERFORM 1 FROM public.paper_balances WHERE user_id = uid AND currency = 'USDT' FOR UPDATE;
  SELECT COALESCE(SUM(invested), 0) INTO refunded
    FROM public.deals WHERE bot_id = _bot_id AND user_id = uid AND status = 'open';
  UPDATE public.paper_balances SET balance = balance + refunded, updated_at = now()
    WHERE user_id = uid AND currency = 'USDT';
  DELETE FROM public.bots WHERE id = _bot_id AND user_id = uid;
  RETURN refunded;
END;
$$;
REVOKE ALL ON FUNCTION public.delete_bot_and_refund(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.delete_bot_and_refund(uuid) TO authenticated, service_role;

-- 4) Perfil: a política de UPDATE passa a ter WITH CHECK (impede reapontar a linha para outro id).
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
