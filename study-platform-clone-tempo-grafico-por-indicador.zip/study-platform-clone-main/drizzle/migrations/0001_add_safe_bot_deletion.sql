CREATE OR REPLACE FUNCTION public.delete_bot_and_refund(_bot_id UUID)
RETURNS NUMERIC
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  refunded NUMERIC := 0;
BEGIN
  SELECT COALESCE(SUM(invested), 0)
  INTO refunded
  FROM public.deals
  WHERE bot_id = _bot_id
    AND user_id = auth.uid()
    AND status = 'open';

  UPDATE public.paper_balances
  SET balance = balance + refunded,
      updated_at = now()
  WHERE user_id = auth.uid()
    AND currency = 'USDT';

  DELETE FROM public.bots
  WHERE id = _bot_id
    AND user_id = auth.uid();

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Bot not found';
  END IF;

  RETURN refunded;
END;
$$;

GRANT EXECUTE ON FUNCTION public.delete_bot_and_refund(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.delete_bot_and_refund(UUID) TO service_role;