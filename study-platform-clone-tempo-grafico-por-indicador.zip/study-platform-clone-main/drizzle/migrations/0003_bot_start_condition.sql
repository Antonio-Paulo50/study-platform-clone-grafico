ALTER TABLE public.bots ADD COLUMN start_condition text NOT NULL DEFAULT 'immediate';
ALTER TABLE public.bots ADD COLUMN indicator_config jsonb;
ALTER TABLE public.bots ADD CONSTRAINT bots_start_condition_check CHECK (start_condition IN ('immediate','indicator'));