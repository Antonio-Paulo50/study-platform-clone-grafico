ALTER TABLE public.bots ADD COLUMN IF NOT EXISTS pairs text[] NOT NULL DEFAULT '{}', ADD COLUMN IF NOT EXISTS indicator_configs jsonb NOT NULL DEFAULT '[]', ADD COLUMN IF NOT EXISTS timeframe text NOT NULL DEFAULT '1h';
UPDATE public.bots SET pairs = ARRAY[pair] WHERE cardinality(pairs) = 0;
UPDATE public.bots SET indicator_configs = jsonb_build_array(indicator_config) WHERE indicator_config IS NOT NULL AND indicator_configs = '[]';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS paper_account_name text NOT NULL DEFAULT 'Conta de simulação';
CREATE OR REPLACE FUNCTION public.manage_paper_account(_action text, _amount numeric DEFAULT 0, _name text DEFAULT NULL) RETURNS numeric LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE uid uuid := auth.uid(); result numeric;
BEGIN
IF uid IS NULL THEN RAISE EXCEPTION 'Unauthorized'; END IF;
PERFORM 1 FROM public.paper_balances WHERE user_id = uid AND currency = 'USDT' FOR UPDATE;
IF _action = 'rename' THEN
IF _name IS NULL OR length(trim(_name)) < 1 OR length(trim(_name)) > 60 THEN RAISE EXCEPTION 'Nome inválido'; END IF;
UPDATE public.profiles SET paper_account_name = trim(_name) WHERE id = uid;
ELSIF _action = 'add' THEN
IF _amount IS NULL OR _amount < 1 OR _amount > 1000000 THEN RAISE EXCEPTION 'Valor inválido'; END IF;
UPDATE public.paper_balances SET balance = balance + _amount, updated_at = now() WHERE user_id = uid AND currency = 'USDT';
ELSIF _action = 'reset' THEN
DELETE FROM public.deals WHERE user_id = uid;
UPDATE public.bots SET total_profit = 0, status = 'paused' WHERE user_id = uid;
UPDATE public.paper_balances SET balance = CASE WHEN currency = 'USDT' THEN 10000 ELSE 0 END, updated_at = now() WHERE user_id = uid;
ELSE RAISE EXCEPTION 'Ação inválida'; END IF;
SELECT balance INTO result FROM public.paper_balances WHERE user_id = uid AND currency = 'USDT';
RETURN result;
END; $$;
REVOKE ALL ON FUNCTION public.manage_paper_account(text,numeric,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.manage_paper_account(text,numeric,text) TO authenticated;
CREATE INDEX IF NOT EXISTS deals_bot_pair_status_idx ON public.deals(bot_id, pair, status);
